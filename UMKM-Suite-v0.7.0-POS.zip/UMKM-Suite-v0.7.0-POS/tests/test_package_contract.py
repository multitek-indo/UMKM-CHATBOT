from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


class PackageContractTest(unittest.TestCase):
    def test_required_files(self):
        for relative in (
            "db/migrations/007_pos.sql",
            "bot_release/app/pos.py",
            "bot_release/app/pos_handlers.py",
            "bridge_app/pos.py",
            "scripts/install.sh",
            "scripts/rollback.sh",
            "scripts/feature_check.sh",
        ):
            self.assertTrue((ROOT / relative).is_file(), relative)

    def test_migration_is_additive_and_tenant_safe(self):
        sql = (ROOT / "db/migrations/007_pos.sql").read_text()
        self.assertNotIn("DROP TABLE", sql.upper())
        self.assertGreaterEqual(sql.upper().count("FORCE ROW LEVEL SECURITY"), 8)
        for table in ("products", "sales", "sale_items", "sale_payments", "stock_movements"):
            self.assertIn(f"CREATE TABLE IF NOT EXISTS {table}", sql)

    def test_installer_does_not_restart_gowa(self):
        script = (ROOT / "scripts/install.sh").read_text()
        self.assertIn("--no-deps wa_bridge", script)
        self.assertNotIn("up -d --build gowa", script)

    def test_ai_pos_requires_confirmation_paths(self):
        ai = (ROOT / "bot_release/app/ai.py").read_text()
        telegram = (ROOT / "bot_release/app/bot.py").read_text()
        whatsapp = (ROOT / "bridge_app/main.py").read_text()
        for intent in ("create_sale", "stock_query", "pos_summary"):
            self.assertIn(f'"{intent}"', ai)
        self.assertIn("AIConfirmSale", telegram)
        self.assertIn('"pos_sale"', whatsapp)


if __name__ == "__main__":
    unittest.main()
