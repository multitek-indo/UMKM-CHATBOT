# Deployment UMKM Suite v0.7.0 POS

## 1. Ruang lingkup perubahan

| Komponen | Tindakan |
|---|---|
| `/home/umkm-bot/current` | Symlink dialihkan ke release baru `/home/umkm-bot/releases/v0.7.0-pos` |
| Telegram `bot` dan `worker` | Build ulang dari release baru |
| PostgreSQL `umkm_bot` | Menjalankan migrasi additive `007_pos.sql` |
| `/home/umkm-gowa/bridge_app` | Di-overlay dan dibangun ulang sebagai `wa_bridge` |
| GOWA engine | Tidak diubah dan tidak direstart |
| `gowa_storage` | Tidak diubah |
| Webhook | Tetap `http://wa_bridge:8080/webhooks/gowa` |
| Stack lain | Tidak disentuh |

## 2. Prasyarat terverifikasi

- Ubuntu 24.04, Docker Engine 29, Docker Compose v5.
- Container `umkm-bot-db-1`, `umkm-bot-bot-1`, `umkm-bot-worker-1`, `umkm-gowa-gowa-1`, dan `umkm-gowa-wa_bridge-1` tersedia.
- Release aktif sebelum upgrade adalah v0.6.0.
- Database PostgreSQL 17 bernama `umkm_bot` menggunakan owner `umkm_owner` dan app role `umkm_app`.
- Network external GOWA tetap mengarah ke `umkm-bot_backend`.

Jika nama/path tersebut berubah, jangan menjalankan `--apply`; sesuaikan script berdasarkan baseline inspeksi.

## 3. Preflight tanpa perubahan

```bash
cd /home/msllab/UMKM-Suite-v0.7.0-POS
sudo ./scripts/install.sh --check
```

Preflight memeriksa path, versi, container, database readiness, compose validity, dan ruang disk. Mode ini tidak menulis database dan tidak me-restart container.

## 4. Instalasi

```bash
sudo ./scripts/install.sh --apply
```

Urutan otomatis:

1. Membuat dump format custom PostgreSQL.
2. Menyalin release aktif menjadi release immutable baru dan meng-overlay source v0.7.0.
3. Membackup source WA bridge.
4. Menjalankan migrasi database dalam transaksi dengan `ON_ERROR_STOP`.
5. Mengalihkan symlink release dan rebuild `bot`/`worker`.
6. Rebuild `wa_bridge` dengan `--no-deps` sehingga GOWA engine tetap berjalan.
7. Menjalankan feature check; jika gagal, source/container aplikasi di-rollback otomatis.

## 5. Verifikasi setelah instalasi

```bash
sudo ./scripts/status.sh
sudo ./scripts/feature_check.sh
sudo docker logs --tail 100 umkm-bot-bot-1
sudo docker logs --tail 100 umkm-gowa-wa_bridge-1
```

Uji tenant dengan data non-produksi terlebih dahulu:

1. Tambah produk dari Telegram OWNER.
2. Cek produk dari WhatsApp yang sudah tertaut pada user/tenant yang sama.
3. Catat satu sale kecil.
4. Pastikan stok turun dan laporan POS/keuangan naik.
5. Void invoice; pastikan stok kembali dan omzet posted turun.
6. Tambah akun CASHIER; pastikan bisa menjual tetapi tidak bisa melihat laporan keuangan atau mengubah stok.
7. Tambah akun VIEWER; pastikan tidak bisa menulis data.
8. Ketik “jual 2 KOPI bayar QRIS” pada Asisten AI; pastikan bot meminta konfirmasi sebelum menyimpan.

## 6. Integrasi Telegram

Tidak perlu token baru. Container bot mengambil `BOT_TOKEN`, `MASTER_TELEGRAM_ID`, database URL, dan konfigurasi Groq dari konfigurasi aktif. Router POS dimuat sebelum router fallback AI sehingga command `/pos`, `/sale`, dan command POS lain tidak tertelan handler AI.

MASTER tetap mengelola seluruh akun global dan dapat masuk sebagai user untuk troubleshooting. OWNER/ADMIN mengelola staf hanya di tenant aktif melalui command `/staff_*`.

## 7. Integrasi GOWA/WhatsApp

Tidak perlu pairing ulang. Bridge menggunakan:

- endpoint GOWA internal `http://gowa:3000`;
- webhook aktif `http://wa_bridge:8080/webhooks/gowa`;
- Basic Auth, webhook HMAC secret, device ID, dan volume sesi yang sudah ada;
- antrean `whatsapp_inbox_events` dan deduplikasi `message_id` yang sudah ada.

Menu `9` dan perintah `POS ...` diproses dalam bridge aktif yang sama. Jangan membuat webhook kedua untuk paket ini.

## 8. Rollback

```bash
sudo ./scripts/rollback.sh --apply
```

Rollback memerlukan `/home/umkm-suite-v0.7.0-pos.state`. Source WA bridge v0.7.0 yang digantikan dipindahkan ke staging bertanggal, bukan dihapus. Schema POS tidak di-drop. Untuk disaster recovery total, gunakan dump yang tercetak saat instalasi dan lakukan restore pada maintenance window tersendiri.

## 9. Batas versi ini

- Antarmuka utama adalah chat; belum ada dashboard web atau printer struk.
- Satu sale menggunakan satu metode pembayaran; tabel pembayaran disiapkan agar split payment dapat ditambahkan pada versi berikutnya.
- Belum ada pembelian/supplier dan pajak terstruktur.
- Laporan finance Excel/PDF lama otomatis menyertakan penjualan POS sebagai `Penjualan POS`; laporan stok disajikan di chat.
