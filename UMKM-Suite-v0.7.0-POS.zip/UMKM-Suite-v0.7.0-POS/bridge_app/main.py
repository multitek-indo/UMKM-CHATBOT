import asyncio
import calendar
import difflib
import hashlib
import hmac
import json
import logging
import mimetypes
import os
import re
from datetime import date, datetime, timedelta, time as dt_time
from decimal import Decimal
from pathlib import Path
import uuid
from zoneinfo import ZoneInfo

import httpx
from fastapi import FastAPI, HTTPException, Request

from bridge_app import ai, db, exporter, pos
from bridge_app.permissions import PermissionDenied, has_permission
from bridge_app.pos_parser import (
    parse_nonnegative_decimal, parse_nonnegative_money, parse_pipe_fields,
    parse_sale_items,
)


JAKARTA = ZoneInfo("Asia/Jakarta")
UTC = ZoneInfo("UTC")

GOWA_URL = os.getenv("GOWA_URL", "http://gowa:3000").rstrip("/")
GOWA_USER = os.environ["GOWA_BASIC_AUTH_USER"]
GOWA_PASSWORD = os.environ["GOWA_BASIC_AUTH_PASSWORD"]
GOWA_DEVICE_ID = os.getenv("GOWA_DEVICE_ID", "umkm-main")
WEBHOOK_SECRET = os.environ["GOWA_WEBHOOK_SECRET"]
BOT_TOKEN = os.environ["BOT_TOKEN"]
MASTER_ID = int(os.environ["MASTER_TELEGRAM_ID"])
REPLY_DELAY = float(os.getenv("WA_MIN_REPLY_INTERVAL_SECONDS", "1.2"))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("umkm-whatsapp")

app = FastAPI(title="UMKM GOWA Bridge", version="0.7.0-pos")

_worker_task = None
_reminder_task = None
_last_send: dict[str, float] = {}
_send_lock = asyncio.Lock()


def rupiah(value: int) -> str:
    n = int(value or 0)
    sign = "-" if n < 0 else ""
    return sign + "Rp{:,.0f}".format(abs(n)).replace(",", ".")


def verify_signature(raw_body: bytes, signature: str | None) -> bool:
    if not signature:
        return False
    received = signature.removeprefix("sha256=").strip()
    expected = hmac.new(
        WEBHOOK_SECRET.encode("utf-8"),
        raw_body,
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, received)


def normalize_jid(value: str | None) -> str:
    return (value or "").strip()


def json_object(value) -> dict:
    # Normalisasi JSON/JSONB asyncpg menjadi dict.
    if value is None:
        return {}
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            decoded = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ValueError("JSON payload database tidak valid") from exc
        if isinstance(decoded, dict):
            return decoded
        raise ValueError("JSON payload database bukan object")
    try:
        return dict(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"Tipe JSON payload tidak didukung: {type(value).__name__}"
        ) from exc


async def _pace(jid: str):
    # Bukan anti-ban; hanya mencegah aplikasi membalas bertubi-tubi karena bug.
    async with _send_lock:
        loop = asyncio.get_running_loop()
        now = loop.time()
        last = _last_send.get(jid, 0.0)
        wait = REPLY_DELAY - (now - last)
        if wait > 0:
            await asyncio.sleep(wait)
        _last_send[jid] = loop.time()


async def gowa_send_text(jid: str, message: str):
    await _pace(jid)
    headers = {"X-Device-Id": GOWA_DEVICE_ID}
    auth = httpx.BasicAuth(GOWA_USER, GOWA_PASSWORD)
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            f"{GOWA_URL}/send/message",
            json={"phone": jid, "message": message[:12000]},
            headers=headers,
            auth=auth,
        )
        response.raise_for_status()


async def gowa_chat_presence(jid: str, action: str):
    """Tampilkan indikator mengetik secara best-effort."""
    if action not in {"start", "stop"}:
        return
    headers = {"X-Device-Id": GOWA_DEVICE_ID}
    auth = httpx.BasicAuth(GOWA_USER, GOWA_PASSWORD)
    try:
        async with httpx.AsyncClient(timeout=8) as client:
            response = await client.post(
                f"{GOWA_URL}/send/chat-presence",
                json={"phone": jid, "action": action},
                headers=headers,
                auth=auth,
            )
            response.raise_for_status()
    except Exception:
        log.debug("Gagal mengubah chat presence untuk %s", jid, exc_info=True)


async def gowa_send_file(jid: str, path: str, caption: str):
    await _pace(jid)
    p = Path(path)
    mime = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
    headers = {"X-Device-Id": GOWA_DEVICE_ID}
    auth = httpx.BasicAuth(GOWA_USER, GOWA_PASSWORD)
    async with httpx.AsyncClient(timeout=90) as client:
        with p.open("rb") as fh:
            response = await client.post(
                f"{GOWA_URL}/send/file",
                data={"phone": jid, "caption": caption[:1000]},
                files={"file": (p.name, fh, mime)},
                headers=headers,
                auth=auth,
            )
        response.raise_for_status()


async def telegram_notify_master(text: str):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.post(
            url,
            json={
                "chat_id": MASTER_ID,
                "text": text,
            },
        )
        response.raise_for_status()


def help_text(business_name: str | None = None) -> str:
    business = business_name or "Usaha Anda"
    return (
        "👋 *SELAMAT DATANG*\n"
        "🤖 *ASISTEN UMKM INDONESIA*\n"
        f"🏪 {business}\n\n"
        "Pilih menu dengan membalas angka:\n\n"
        "1️⃣  💰 Catat Pemasukan\n"
        "2️⃣  💸 Catat Pengeluaran\n"
        "3️⃣  📊 Ringkasan Keuangan\n"
        "4️⃣  ⏰ Kelola Pengingat\n"
        "5️⃣  📤 Export Laporan\n"
        "6️⃣  🤖 Tanya Asisten AI\n"
        "7️⃣  🏪 Pengaturan & Akun\n"
        "8️⃣  ❓ Bantuan & Contoh\n\n"
        "9️⃣  🛒 POS & Stok\n\n"
        "0️⃣  🏠 Menu Utama\n\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "⚡ *Mode Cepat*\n"
        "Anda juga bisa langsung mengetik:\n"
        "_keluar 50rb beli bensin_\n"
        "_pemasukan 1,5jt servis mesin_\n"
        "_berapa pengeluaran bulan ini?_\n\n"
        "💡 Bot toleran huruf besar/kecil dan typo ringan.\n"
        "Ketik *0* atau *MENU* kapan saja untuk kembali."
    )


def help_examples() -> str:
    return (
        "❓ *BANTUAN & CONTOH*\n\n"
        "💰 Pemasukan: `pemasukan 50000 penjualan kopi`\n"
        "💸 Pengeluaran: `keluar 75rb beli bensin`\n"
        "⏰ Pengingat: `ingatkan besok jam 9 bayar listrik`\n"
        "🔁 Berulang: `ingatkan setiap tanggal 1 jam 9 bayar listrik`\n"
        "📊 Analisis: `berapa pengeluaran bulan ini?`\n\n"
        "5️⃣ Export Excel/PDF\n"
        "0️⃣ Menu Utama"
    )


def first_choice(text: str) -> str | None:
    raw = (text or "").strip().lower()
    if not raw:
        return None

    cleaned = (
        raw.replace("1️⃣", "1").replace("2️⃣", "2")
        .replace("3️⃣", "3").replace("4️⃣", "4")
        .replace("5️⃣", "5").replace("6️⃣", "6")
        .replace("7️⃣", "7").replace("8️⃣", "8")
        .replace("9️⃣", "9")
        .replace("0️⃣", "0")
    )
    m = re.match(r"^\s*([0-9])(?:\s|[.)-]|$)", cleaned)
    if m:
        return m.group(1)

    aliases = {
        "menu": "0", "/menu": "0", "start": "0", "/start": "0",
        "home": "0", "kembali": "0", "back": "0",
        "pemasukan": "1", "masuk": "1", "income": "1",
        "catat pemasukan": "1",
        "pengeluaran": "2", "keluar": "2", "expense": "2",
        "catat pengeluaran": "2",
        "ringkasan": "3", "ringkasan keuangan": "3",
        "summary": "3", "saldo": "3",
        "pengingat": "4", "buat pengingat": "4", "reminder": "4",
        "export": "5", "export laporan": "5", "laporan": "5",
        "ai": "6", "asisten": "6", "asisten ai": "6",
        "tanya ai": "6", "tanya asisten ai": "6",
        "pos": "9", "stok": "9", "kasir": "9", "pos dan stok": "9",
        "usaha": "7", "usaha saya": "7",
        "pengaturan": "7", "pengaturan usaha": "7",
        "help": "8", "bantuan": "8", "panduan": "8",
    }
    return aliases.get(raw)


def navigation_alias(text: str) -> str | None:
    """Navigasi global berbasis kata dan typo ringan."""
    raw = (text or "").strip().lower()
    if not raw:
        return None

    normalized = re.sub(r"[^a-z0-9/ ]+", " ", raw)
    normalized = re.sub(r"\s+", " ", normalized).strip()

    aliases = {
        "menu": "0", "/menu": "0", "start": "0", "/start": "0",
        "home": "0", "kembali": "0", "back": "0",
        "pemasukan": "1", "catat pemasukan": "1",
        "pengeluaran": "2", "catat pengeluaran": "2",
        "ringkasan": "3", "ringkasan keuangan": "3",
        "pengingat": "4", "buat pengingat": "4",
        "export": "5", "export laporan": "5",
        "asisten ai": "6", "tanya ai": "6", "tanya asisten ai": "6",
        "usaha": "7", "usaha saya": "7",
        "pengaturan": "7", "pengaturan usaha": "7",
        "bantuan": "8", "help": "8", "panduan": "8",
    }
    if normalized in aliases:
        return aliases[normalized]

    typo_aliases = {
        "mesnu": "0", "mneu": "0", "meun": "0", "men": "0",
        "ringaksan": "3",
        "pengigat": "4", "pengingatn": "4",
        "asisten ia": "6", "asistent ai": "6",
        "pengaturan usha": "7", "pengaturan usah": "7",
    }
    if normalized in typo_aliases:
        return typo_aliases[normalized]

    if len(normalized) <= 24 and not any(ch.isdigit() for ch in normalized):
        close = difflib.get_close_matches(
            normalized, list(aliases.keys()), n=1, cutoff=0.86
        )
        if close:
            return aliases[close[0]]

    return None


def parse_money_input(text: str) -> int | None:
    raw = (text or "").lower().strip().replace("rp", "").replace(" ", "")
    raw = raw.replace(",", ".")
    multiplier = 1
    for suffix, mult in (
        ("ribu", 1_000), ("rb", 1_000),
        ("juta", 1_000_000), ("jt", 1_000_000),
    ):
        if raw.endswith(suffix):
            multiplier = mult
            raw = raw[:-len(suffix)]
            break

    try:
        if multiplier > 1:
            if not re.fullmatch(r"\d+(\.\d+)?", raw):
                return None
            value = int(float(raw) * multiplier)
        else:
            digits = re.sub(r"[^\d]", "", raw)
            if not digits:
                return None
            value = int(digits)
    except Exception:
        return None

    if value <= 0 or value > 999_999_999_999:
        return None
    return value



MONTHS_ID = {
    "januari": 1, "jan": 1,
    "februari": 2, "feb": 2,
    "maret": 3, "mar": 3,
    "april": 4, "apr": 4,
    "mei": 5,
    "juni": 6, "jun": 6,
    "juli": 7, "jul": 7,
    "agustus": 8, "agu": 8, "agt": 8,
    "september": 9, "sep": 9,
    "oktober": 10, "okt": 10,
    "november": 11, "nov": 11,
    "desember": 12, "des": 12,
}

WEEKDAYS_ID = {
    "senin": 0,
    "selasa": 1,
    "rabu": 2,
    "kamis": 3,
    "jumat": 4,
    "jum'at": 4,
    "sabtu": 5,
    "minggu": 6,
}

WEEKDAY_NAMES = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]


def parse_time_input(text: str) -> dt_time | None:
    raw = (text or "").strip().lower()

    # Dalam kalimat panjang, angka tanggal/nominal tidak boleh dianggap jam.
    m = re.search(r"\bjam\s*([01]?\d|2[0-3])(?:[:.]([0-5]\d))?\b", raw)
    if not m:
        m = re.search(r"\b([01]?\d|2[0-3])[:.]([0-5]\d)\b", raw)
    if not m and re.fullmatch(r"(?:[01]?\d|2[0-3])", raw):
        m = re.fullmatch(r"([01]?\d|2[0-3])", raw)
    if not m:
        return None
    hour = int(m.group(1))
    minute = int(m.group(2) or 0) if m.lastindex and m.lastindex >= 2 else 0
    return dt_time(hour=hour, minute=minute)

def parse_date_input(text: str) -> date | None:
    raw = (text or "").strip().lower()
    today = datetime.now(JAKARTA).date()
    if re.search(r"\b(hari ini|today)\b", raw):
        return today
    if re.search(r"\b(besok|tomorrow)\b", raw):
        return today + timedelta(days=1)
    if re.search(r"\blusa\b", raw):
        return today + timedelta(days=2)

    m = re.search(r"\b(\d{1,2})[-/](\d{1,2})[-/](\d{4})\b", raw)
    if m:
        try:
            return date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        except ValueError:
            return None

    m = re.search(
        r"\b(\d{1,2})\s+"
        r"(januari|jan|februari|feb|maret|mar|april|apr|mei|juni|jun|juli|jul|agustus|agu|agt|september|sep|oktober|okt|november|nov|desember|des)"
        r"(?:\s+(\d{4}))?\b",
        raw,
    )
    if m:
        day = int(m.group(1))
        month = MONTHS_ID[m.group(2)]
        year = int(m.group(3) or today.year)
        try:
            candidate = date(year, month, day)
        except ValueError:
            return None
        if m.group(3) is None and candidate < today:
            try:
                candidate = date(year + 1, month, day)
            except ValueError:
                return None
        return candidate

    return None


def parse_weekday_input(text: str) -> int | None:
    raw = (text or "").strip().lower()
    if raw in WEEKDAYS_ID:
        return WEEKDAYS_ID[raw]
    choice = first_choice(raw)
    if choice and choice in {"1", "2", "3", "4", "5", "6", "7"}:
        return int(choice) - 1
    return None


def _combine_local(d: date, t: dt_time) -> datetime:
    return datetime.combine(d, t, tzinfo=JAKARTA)


def next_daily_due(clock: dt_time) -> datetime:
    now = datetime.now(JAKARTA)
    candidate = _combine_local(now.date(), clock)
    if candidate <= now:
        candidate += timedelta(days=1)
    return candidate


def next_weekly_due(weekday: int, clock: dt_time) -> datetime:
    now = datetime.now(JAKARTA)
    delta = (weekday - now.weekday()) % 7
    candidate = _combine_local(now.date() + timedelta(days=delta), clock)
    if candidate <= now:
        candidate += timedelta(days=7)
    return candidate


def next_monthly_due(day: int, clock: dt_time) -> datetime:
    now = datetime.now(JAKARTA)
    year, month = now.year, now.month
    for _ in range(24):
        last_day = calendar.monthrange(year, month)[1]
        candidate = _combine_local(date(year, month, min(day, last_day)), clock)
        if candidate > now:
            return candidate
        if month == 12:
            year += 1
            month = 1
        else:
            month += 1
    raise ValueError("Tidak dapat menghitung jadwal bulanan")


def recurrence_label(row) -> str:
    kind = row["recurrence_type"] or "once"
    due = row["due_at"].astimezone(JAKARTA)
    if kind == "daily":
        return f"Setiap hari · {due.strftime('%H:%M')} WIB"
    if kind == "weekly":
        wd = row["recurrence_weekday"]
        name = WEEKDAY_NAMES[int(wd)] if wd is not None and 0 <= int(wd) <= 6 else due.strftime('%A')
        return f"Setiap {name} · {due.strftime('%H:%M')} WIB"
    if kind == "monthly":
        day = row["recurrence_day"] or due.day
        return f"Setiap tanggal {day} · {due.strftime('%H:%M')} WIB"
    return due.strftime("%d-%m-%Y %H:%M WIB")


def clean_quick_reminder_message(text: str) -> str:
    value = (text or "").strip()
    value = re.sub(r"(?i)^\s*((?:buatkan|buat)\s+)?(pengingat|ingatkan)\s*", "", value)
    value = re.sub(r"(?i)\bsetiap\s+tanggal\s+\d{1,2}\b", "", value)
    value = re.sub(r"(?i)\bsetiap\s+(hari|senin|selasa|rabu|kamis|jumat|jum'at|sabtu|minggu)\b", "", value)
    value = re.sub(r"(?i)\b(?:tanggal\s+)?\d{1,2}\s+(?:januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember)(?:\s+\d{4})?\b", "", value)
    value = re.sub(r"(?i)\b(?:hari\s+ini|besok|lusa)\b", "", value)
    value = re.sub(r"(?i)\bjam\s*\d{1,2}(?:[:.]\d{2})?\b", "", value)
    value = re.sub(r"\s+", " ", value).strip(" ,.-")
    return value or "Pengingat"


def schedule_payload(
    message: str,
    due_local: datetime,
    recurrence_type: str = "once",
    recurrence_day: int | None = None,
    recurrence_weekday: int | None = None,
):
    return {
        "message": message,
        "reminder_at": due_local.isoformat(),
        "recurrence_type": recurrence_type,
        "recurrence_interval": 1,
        "recurrence_day": recurrence_day,
        "recurrence_weekday": recurrence_weekday,
        "recurrence_time": due_local.strftime("%H:%M:%S"),
    }


async def set_reminder_confirmation(jid: str, payload: dict, action_type: str = "reminder"):
    due_local = datetime.fromisoformat(payload["reminder_at"]).astimezone(JAKARTA)
    kind = payload.get("recurrence_type", "once")
    if kind == "daily":
        schedule = f"Setiap hari · {due_local.strftime('%H:%M')} WIB"
    elif kind == "weekly":
        wd = int(payload.get("recurrence_weekday", due_local.weekday()))
        schedule = f"Setiap {WEEKDAY_NAMES[wd]} · {due_local.strftime('%H:%M')} WIB"
    elif kind == "monthly":
        schedule = f"Setiap tanggal {payload.get('recurrence_day') or due_local.day} · {due_local.strftime('%H:%M')} WIB"
    else:
        schedule = due_local.strftime("%d-%m-%Y %H:%M WIB")

    await db.set_pending_action(jid, action_type, payload, ttl_minutes=20)
    title = "🤖 *KONFIRMASI PENGINGAT*" if action_type == "reminder" else "✏️ *KONFIRMASI PERUBAHAN JADWAL*"
    await gowa_send_text(
        jid,
        f"{title}\\n\\n"
        f"📝 {payload.get('message') or '-'}\\n"
        f"🗓 {schedule}\\n\\n"
        "1️⃣ SIMPAN\\n"
        "2️⃣ EDIT\\n"
        "0️⃣ BATAL",
    )


async def send_reminder_menu(jid: str):
    await db.set_pending_action(jid, "menu_reminder", {}, ttl_minutes=20)
    await gowa_send_text(
        jid,
        "⏰ *PENGINGAT*\\n\\n"
        "1️⃣ ➕ Buat Pengingat\\n"
        "2️⃣ 📋 Pengingat Aktif\\n"
        "3️⃣ ✏️ Edit Pengingat\\n"
        "4️⃣ 🗑 Hapus Pengingat\\n\\n"
        "0️⃣ 🏠 Menu Utama",
    )


async def send_active_reminders(jid: str, mode: str = "view"):
    rows = await db.list_active_reminders(jid, 20)
    if not rows:
        await db.set_pending_action(jid, "menu_reminder", {}, ttl_minutes=20)
        await gowa_send_text(
            jid,
            "📋 *PENGINGAT AKTIF*\\n\\nBelum ada pengingat aktif.\\n\\n"
            "1️⃣ Buat Pengingat\\n0️⃣ Menu Utama",
        )
        return

    lines = ["📋 *PENGINGAT AKTIF*", ""]
    ids = []
    for i, row in enumerate(rows, 1):
        ids.append(str(row["id"]))
        lines.append(f"{i}️⃣ *{row['message']}*")
        lines.append(f"   🗓 {recurrence_label(row)}")
        lines.append(f"   🔔 Berikutnya: {row['due_at'].astimezone(JAKARTA).strftime('%d-%m-%Y %H:%M')} WIB")
        lines.append("")

    if mode == "edit":
        await db.set_pending_action(jid, "reminder_edit_pick", {"ids": ids}, ttl_minutes=20)
        lines.append("Balas nomor pengingat yang ingin *diedit*.")
        lines.append("0️⃣ Kembali")
    elif mode == "delete":
        await db.set_pending_action(jid, "reminder_delete_pick", {"ids": ids}, ttl_minutes=20)
        lines.append("Balas nomor pengingat yang ingin *dihapus*.")
        lines.append("0️⃣ Kembali")
    else:
        await db.set_pending_action(jid, "menu_reminder", {}, ttl_minutes=20)
        lines.extend(["1️⃣ Buat Pengingat", "3️⃣ Edit", "4️⃣ Hapus", "0️⃣ Menu Utama"])

    await gowa_send_text(jid, "\\n".join(lines))


async def begin_reminder_schedule(jid: str, payload: dict):
    kind = payload["recurrence_type"]
    if kind == "once":
        await db.set_pending_action(jid, "reminder_once_date", payload, ttl_minutes=20)
        await gowa_send_text(
            jid,
            "📅 *TANGGAL PENGINGAT*\\n\\n"
            "Contoh: `01-09-2026`, `besok`, atau `lusa`\\n\\n"
            "0️⃣ Batal & kembali",
        )
    elif kind == "daily":
        await db.set_pending_action(jid, "reminder_time", payload, ttl_minutes=20)
        await gowa_send_text(jid, "🕘 Jam berapa setiap hari?\\nContoh: `09:00`\\n\\n0️⃣ Batal")
    elif kind == "weekly":
        await db.set_pending_action(jid, "reminder_weekday", payload, ttl_minutes=20)
        await gowa_send_text(
            jid,
            "📅 *PILIH HARI*\\n\\n"
            "1️⃣ Senin\\n2️⃣ Selasa\\n3️⃣ Rabu\\n4️⃣ Kamis\\n"
            "5️⃣ Jumat\\n6️⃣ Sabtu\\n7️⃣ Minggu\\n\\n0️⃣ Batal",
        )
    elif kind == "monthly":
        await db.set_pending_action(jid, "reminder_monthday", payload, ttl_minutes=20)
        await gowa_send_text(jid, "📅 Tanggal berapa setiap bulan?\\nKetik angka *1–31*.\\n\\n0️⃣ Batal")


async def try_quick_reminder(jid: str, text: str) -> bool:
    lower = (text or "").lower()
    if "pengingat" not in lower and "ingatkan" not in lower:
        return False

    if re.search(r"pengingat.{0,15}(aktif|saya)|daftar\s+pengingat", lower):
        await send_active_reminders(jid, "view")
        return True

    message = clean_quick_reminder_message(text)
    clock = parse_time_input(text)

    m = re.search(r"(?i)setiap\s+tanggal\s+(\d{1,2})", text)
    if m:
        day = int(m.group(1))
        if not 1 <= day <= 31:
            await gowa_send_text(jid, "Tanggal bulanan harus 1–31.")
            return True
        if clock is None:
            await db.set_pending_action(
                jid, "quick_monthly_time", {"message": message, "day": day}, ttl_minutes=20
            )
            await gowa_send_text(jid, f"🕘 Jam berapa setiap tanggal *{day}*?\\nContoh: `09:00`")
            return True
        due = next_monthly_due(day, clock)
        await set_reminder_confirmation(jid, schedule_payload(message, due, "monthly", recurrence_day=day))
        return True

    if re.search(r"(?i)setiap\s+hari", text):
        if clock is None:
            await db.set_pending_action(jid, "quick_daily_time", {"message": message}, ttl_minutes=20)
            await gowa_send_text(jid, "🕘 Jam berapa setiap hari?\\nContoh: `09:00`")
            return True
        due = next_daily_due(clock)
        await set_reminder_confirmation(jid, schedule_payload(message, due, "daily"))
        return True

    for name, wd in WEEKDAYS_ID.items():
        if re.search(rf"(?i)setiap\s+{re.escape(name)}\b", text):
            if clock is None:
                await db.set_pending_action(
                    jid, "quick_weekly_time", {"message": message, "weekday": wd}, ttl_minutes=20
                )
                await gowa_send_text(jid, f"🕘 Jam berapa setiap *{WEEKDAY_NAMES[wd]}*?\\nContoh: `09:00`")
                return True
            due = next_weekly_due(wd, clock)
            await set_reminder_confirmation(jid, schedule_payload(message, due, "weekly", recurrence_weekday=wd))
            return True

    parsed_date = parse_date_input(text)
    if parsed_date:
        if clock is None:
            await db.set_pending_action(
                jid,
                "quick_once_time",
                {"message": message, "date": parsed_date.isoformat()},
                ttl_minutes=20,
            )
            await gowa_send_text(
                jid,
                f"🕘 Jam berapa pada tanggal *{parsed_date.strftime('%d-%m-%Y')}*?\\nContoh: `09:00`",
            )
            return True
        due = _combine_local(parsed_date, clock)
        if due <= datetime.now(JAKARTA):
            await gowa_send_text(jid, "Waktu tersebut sudah lewat. Gunakan waktu yang akan datang.")
            return True
        await set_reminder_confirmation(jid, schedule_payload(message, due, "once"))
        return True

    # Reminder intent sudah jelas tetapi jadwal belum lengkap: simpan konteks.
    await db.set_pending_action(jid, "quick_need_when", {"message": message}, ttl_minutes=20)
    await gowa_send_text(
        jid,
        "🗓 Kapan saya harus mengingatkan?\n\n"
        "Contoh:\n"
        "• `besok jam 9`\n"
        "• `1 September 2026 jam 09:00`\n"
        "• `setiap tanggal 1 jam 09:00`",
    )
    return True


async def send_main_menu(jid: str):
    await db.clear_pending_action(jid)
    current = await db.get_whatsapp_access(jid)
    await gowa_send_text(
        jid,
        help_text(current["business_name"] if current else None),
    )


async def send_export_menu(jid: str):
    await db.set_pending_action(jid, "menu_export", {}, ttl_minutes=20)
    await gowa_send_text(
        jid,
        "📤 *EXPORT LAPORAN*\n\n"
        "1️⃣  📗 Excel — Bulan Ini\n"
        "2️⃣  📕 PDF — Bulan Ini\n"
        "3️⃣  📗 Excel — Semua Data\n"
        "4️⃣  📕 PDF — Semua Data\n"
        "5️⃣  📅 Rentang Tanggal\n\n"
        "0️⃣  🏠 Menu Utama",
    )

async def send_business_menu(jid: str):
    current = await db.get_whatsapp_access(jid)
    await db.set_pending_action(jid, "menu_business", {}, ttl_minutes=20)
    linked = "Terhubung" if current and current["user_id"] else "-"
    await gowa_send_text(
        jid,
        "🏪 *PENGATURAN & AKUN*\n\n"
        f"Nama usaha: *{current['business_name'] or '-'}*\n"
        f"WhatsApp: {current['phone_number'] or '-'}\n\n"
        "1️⃣  ✏️ Ubah Nama Usaha\n"
        "2️⃣  🔗 Hubungkan dengan Telegram\n"
        "0️⃣  🏠 Menu Utama",
    )


def _qty(value) -> str:
    return f"{Decimal(value):f}".rstrip("0").rstrip(".") or "0"


async def send_pos_menu(jid: str):
    await db.set_pending_action(jid, "menu_pos", {}, ttl_minutes=20)
    await gowa_send_text(
        jid,
        "🛒 *POS & STOK v0.7.0*\n\n"
        "Ketik salah satu perintah:\n"
        "• `POS PRODUK`\n"
        "• `POS STOK RENDAH`\n"
        "• `POS STOK KOPI`\n"
        "• `POS JUAL KOPI:2,ROTI:1 | QRIS`\n"
        "• `POS BATAL POS-YYYYMMDD-00001 | Alasan` (OWNER/ADMIN)\n"
        "• `POS LAPORAN HARI INI`\n\n"
        "OWNER/ADMIN/INVENTORY:\n"
        "• `POS TAMBAH PRODUK KOPI | Kopi Susu | 18000 | 9000 | 20 | cup | 5`\n"
        "• `POS SET STOK KOPI | 24 | Hitung gudang`\n\n"
        "Setiap penjualan memperbarui stok dan pemasukan dalam satu transaksi database.\n\n"
        "0️⃣ Menu Utama",
    )


async def handle_pos_command(jid: str, text: str) -> bool:
    raw = re.sub(r"(?i)^\s*pos\s*", "", text or "").strip()
    upper = raw.upper()
    try:
        if upper in {"", "MENU", "BANTUAN"}:
            await send_pos_menu(jid)
            return True

        if upper == "PRODUK" or upper == "STOK RENDAH":
            low_only = upper == "STOK RENDAH"
            ctx, rows = await pos.list_products(jid, low_stock_only=low_only)
            if not rows:
                await gowa_send_text(jid, "Belum ada produk yang cocok.\n\n0️⃣ Menu Utama")
                return True
            lines = [f"📦 *{'STOK RENDAH' if low_only else 'DAFTAR PRODUK'}*", f"🏪 {ctx['business_name']}", ""]
            for row in rows:
                mark = " ⚠️" if row["stock_on_hand"] <= row["min_stock"] else ""
                lines.append(f"• `{row['sku']}` — {row['name']} · {_qty(row['stock_on_hand'])} {row['unit']} · {rupiah(row['sell_price'])}{mark}")
            await gowa_send_text(jid, "\n".join(lines) + "\n\n0️⃣ Menu Utama")
            return True

        match = re.match(r"(?i)^STOK\s+(.+)$", raw)
        if match:
            _, row = await pos.get_product(jid, match.group(1))
            if not row:
                raise LookupError("Produk tidak ditemukan.")
            await gowa_send_text(jid, f"📦 `{row['sku']}` — *{row['name']}*\nStok: *{_qty(row['stock_on_hand'])} {row['unit']}*\nMinimum: {_qty(row['min_stock'])}\nHarga jual: {rupiah(row['sell_price'])}\n\n0️⃣ Menu Utama")
            return True

        match = re.match(r"(?is)^JUAL\s+(.+)$", raw)
        if match:
            item_text, method = parse_pipe_fields(match.group(1), 2)
            items = parse_sale_items(item_text)
            _, sale, repeated = await pos.create_sale(jid, items, method, "whatsapp", str(uuid.uuid4()))
            await gowa_send_text(jid, f"✅ *PENJUALAN TERCATAT*\nInvoice: `{sale['invoice_no']}`\nTotal: *{rupiah(sale['total'])}*\nBayar: {sale['payment_method']}\n\nStok dan pemasukan sudah diperbarui atomik.\n\n0️⃣ Menu Utama")
            return True

        match = re.match(r"(?is)^TAMBAH\s+PRODUK\s+(.+)$", raw)
        if match:
            sku, name, sell, cost, opening, unit, minimum = parse_pipe_fields(match.group(1), 7)
            _, row = await pos.add_product(
                jid, sku, name, parse_nonnegative_money(sell), parse_nonnegative_money(cost),
                parse_nonnegative_decimal(opening), unit, parse_nonnegative_decimal(minimum),
            )
            await gowa_send_text(jid, f"✅ Produk `{row['sku']}` tersimpan. Stok {_qty(row['stock_on_hand'])}, harga {rupiah(row['sell_price'])}.\n\n0️⃣ Menu Utama")
            return True

        match = re.match(r"(?is)^BATAL\s+(.+)$", raw)
        if match:
            fields = parse_pipe_fields(match.group(1), (1, 2))
            reason = fields[1] if len(fields) == 2 else "Dibatalkan melalui WhatsApp"
            _, sale, repeated = await pos.void_sale(jid, fields[0], reason)
            label = "ℹ️ Invoice sudah void" if repeated else "✅ Penjualan dibatalkan"
            await gowa_send_text(jid, f"{label}: `{sale['invoice_no']}`.\nStok dikembalikan dan pemasukan di-void.\n\n0️⃣ Menu Utama")
            return True

        match = re.match(r"(?is)^SET\s+STOK\s+(.+)$", raw)
        if match:
            sku, amount, note = parse_pipe_fields(match.group(1), 3)
            _, row, delta = await pos.set_stock(jid, sku, parse_nonnegative_decimal(amount), note)
            await gowa_send_text(jid, f"✅ Stok `{row['sku']}` menjadi {_qty(row['stock_on_hand'])}; perubahan {_qty(delta)}.\n\n0️⃣ Menu Utama")
            return True

        if upper in {"LAPORAN", "LAPORAN HARI INI", "LAPORAN BULAN"}:
            today = date.today()
            start = today.replace(day=1) if upper == "LAPORAN BULAN" else today
            ctx, row, low = await pos.pos_summary(jid, start, today)
            await gowa_send_text(jid, f"📊 *LAPORAN POS*\n🏪 {ctx['business_name']}\nPeriode: {start:%d-%m-%Y} s.d. {today:%d-%m-%Y}\nTransaksi: *{row['sales_count']}*\nOmzet: *{rupiah(row['revenue'])}*\nLaba kotor: *{rupiah(row['gross_profit'])}*\nSKU stok rendah: *{low}*\n\n0️⃣ Menu Utama")
            return True

        await gowa_send_text(jid, "⚠️ Perintah POS belum dikenali.\n\nKetik *POS* untuk melihat contoh.")
        return True
    except (PermissionDenied, PermissionError) as exc:
        await gowa_send_text(jid, f"⛔ {exc}\n\n0️⃣ Menu Utama")
        return True
    except (ValueError, LookupError) as exc:
        await gowa_send_text(jid, f"⚠️ {exc}\n\nKetik *POS* untuk melihat format.\n0️⃣ Menu Utama")
        return True

async def start_guided_transaction(jid: str, tx_type: str):
    label = "PEMASUKAN" if tx_type == "income" else "PENGELUARAN"
    icon = "💰" if tx_type == "income" else "💸"
    state = "guided_income_amount" if tx_type == "income" else "guided_expense_amount"
    await db.set_pending_action(jid, state, {}, ttl_minutes=15)
    await gowa_send_text(
        jid,
        f"{icon} *CATAT {label} — LANGKAH 1/2*\n\n"
        "Masukkan *nominal* saja.\n\n"
        "Contoh: `50000`, `75rb`, atau `1,5jt`\n\n"
        "0️⃣ Batal & kembali ke Menu",
    )


async def handle_menu_state(jid: str, text: str) -> bool:
    pending = await db.get_pending_action(jid)
    if not pending:
        return False

    action_type = pending["action_type"]
    managed_prefixes = (
        "menu_", "guided_", "reminder_", "quick_", "export_", "pos_"
    )
    if not action_type.startswith(managed_prefixes):
        return False

    raw = (text or "").strip()
    lower = raw.lower()
    choice = first_choice(raw)
    payload = json_object(pending["payload"])

    if lower in {"menu", "/menu", "start", "/start", "kembali", "back"} or choice == "0":
        await send_main_menu(jid)
        return True

    # Guided transactions.
    if action_type in {"guided_income_amount", "guided_expense_amount"}:
        amount = parse_money_input(raw)
        if amount is None:
            await gowa_send_text(jid, "⚠️ Nominal belum dikenali. Contoh: *50000*, *75rb*, atau *1,5jt*.\n\n0️⃣ Menu Utama")
            return True
        tx_type = "income" if action_type == "guided_income_amount" else "expense"
        next_state = "guided_income_desc" if tx_type == "income" else "guided_expense_desc"
        await db.set_pending_action(jid, next_state, {"amount": amount}, ttl_minutes=20)
        await gowa_send_text(
            jid,
            "📝 *LANGKAH 2/2 — KETERANGAN*\n\n"
            f"Nominal: *{rupiah(amount)}*\n\n"
            "Ketik keterangannya.\nContoh: *penjualan sparepart* atau *beli bensin*.\n\n0️⃣ Batal",
        )
        return True

    if action_type in {"guided_income_desc", "guided_expense_desc"}:
        if len(raw) < 2:
            await gowa_send_text(jid, "Keterangan terlalu pendek. Silakan ketik kembali.")
            return True
        amount = int(payload["amount"])
        tx_type = "income" if action_type == "guided_income_desc" else "expense"
        await db.clear_pending_action(jid)
        phrase = f"catat {'pemasukan' if tx_type == 'income' else 'pengeluaran'} {amount} {raw}"
        await handle_ai(jid, phrase)
        return True

    # Reminder main menu.
    if action_type == "menu_reminder":
        if choice == "1":
            await db.set_pending_action(jid, "reminder_type", {}, ttl_minutes=20)
            await gowa_send_text(
                jid,
                "➕ *BUAT PENGINGAT*\n\nPilih jenis jadwal:\n\n"
                "1️⃣ Sekali\n2️⃣ Setiap Hari\n3️⃣ Setiap Minggu\n4️⃣ Setiap Bulan\n\n0️⃣ Kembali",
            )
            return True
        if choice == "2":
            await send_active_reminders(jid, "view")
            return True
        if choice == "3":
            await send_active_reminders(jid, "edit")
            return True
        if choice == "4":
            await send_active_reminders(jid, "delete")
            return True
        await gowa_send_text(jid, "⚠️ Pilih *1–4* atau *0*.")
        return True

    if action_type in {"reminder_type", "reminder_edit_type"}:
        kinds = {"1": "once", "2": "daily", "3": "weekly", "4": "monthly"}
        if choice not in kinds:
            await gowa_send_text(jid, "⚠️ Pilih *1*, *2*, *3*, *4*, atau *0*.")
            return True
        new_payload = dict(payload)
        new_payload["recurrence_type"] = kinds[choice]
        if action_type == "reminder_type":
            await db.set_pending_action(jid, "reminder_message", new_payload, ttl_minutes=20)
            await gowa_send_text(jid, "📝 Apa yang ingin diingatkan?\nContoh: *bayar listrik Rp100.000*\n\n0️⃣ Batal")
        else:
            new_payload["mode"] = "edit"
            await begin_reminder_schedule(jid, new_payload)
        return True

    if action_type == "reminder_message":
        if len(raw) < 2:
            await gowa_send_text(jid, "Isi pengingat terlalu pendek.")
            return True
        payload["message"] = raw[:500]
        await begin_reminder_schedule(jid, payload)
        return True

    if action_type == "reminder_once_date":
        d = parse_date_input(raw)
        if not d:
            await gowa_send_text(jid, "⚠️ Tanggal tidak dikenali. Contoh: *01-09-2026* atau *besok*.")
            return True
        payload["date"] = d.isoformat()
        await db.set_pending_action(jid, "reminder_time", payload, ttl_minutes=20)
        await gowa_send_text(jid, f"🕘 Jam berapa pada *{d.strftime('%d-%m-%Y')}*?\nContoh: `09:00`")
        return True

    if action_type == "reminder_weekday":
        wd = parse_weekday_input(raw)
        if wd is None:
            await gowa_send_text(jid, "⚠️ Pilih hari 1–7 atau ketik nama hari, mis. *Senin*.")
            return True
        payload["recurrence_weekday"] = wd
        await db.set_pending_action(jid, "reminder_time", payload, ttl_minutes=20)
        await gowa_send_text(jid, f"🕘 Jam berapa setiap *{WEEKDAY_NAMES[wd]}*?\nContoh: `09:00`")
        return True

    if action_type == "reminder_monthday":
        try:
            day = int(re.sub(r"[^0-9]", "", raw))
        except Exception:
            day = 0
        if not 1 <= day <= 31:
            await gowa_send_text(jid, "⚠️ Ketik tanggal *1–31*.")
            return True
        payload["recurrence_day"] = day
        await db.set_pending_action(jid, "reminder_time", payload, ttl_minutes=20)
        await gowa_send_text(jid, f"🕘 Jam berapa setiap tanggal *{day}*?\nContoh: `09:00`")
        return True

    if action_type == "reminder_time":
        clock = parse_time_input(raw)
        if not clock:
            await gowa_send_text(jid, "⚠️ Jam tidak dikenali. Contoh: *09:00* atau *jam 9*.")
            return True
        kind = payload["recurrence_type"]
        if kind == "once":
            d = date.fromisoformat(payload["date"])
            due = _combine_local(d, clock)
            if due <= datetime.now(JAKARTA):
                await gowa_send_text(jid, "⚠️ Waktu tersebut sudah lewat. Masukkan waktu yang akan datang.")
                return True
        elif kind == "daily":
            due = next_daily_due(clock)
        elif kind == "weekly":
            due = next_weekly_due(int(payload["recurrence_weekday"]), clock)
        else:
            due = next_monthly_due(int(payload["recurrence_day"]), clock)

        schedule = schedule_payload(
            payload.get("message") or "Pengingat",
            due,
            kind,
            payload.get("recurrence_day"),
            payload.get("recurrence_weekday"),
        )
        if payload.get("mode") == "edit":
            schedule["reminder_id"] = payload["reminder_id"]
            await set_reminder_confirmation(jid, schedule, "reminder_schedule_update")
        else:
            await set_reminder_confirmation(jid, schedule, "reminder")
        return True

    # Quick reminder continuation (fixes clarification context loss).
    if action_type == "quick_need_when":
        await db.clear_pending_action(jid)
        combined = f"ingatkan {payload.get('message') or 'Pengingat'} {raw}"
        if await try_quick_reminder(jid, combined):
            return True
        await db.set_pending_action(jid, "quick_need_when", payload, ttl_minutes=20)
        await gowa_send_text(
            jid,
            "⚠️ Jadwal belum dikenali. Contoh:\n"
            "• `besok jam 9`\n"
            "• `1 September 2026 jam 09:00`\n"
            "• `setiap tanggal 1 jam 09:00`",
        )
        return True

    if action_type in {"quick_monthly_time", "quick_daily_time", "quick_weekly_time", "quick_once_time"}:
        clock = parse_time_input(raw)
        if not clock:
            await gowa_send_text(jid, "⚠️ Jam tidak dikenali. Contoh: *09:00* atau *jam 9*.")
            return True
        message = payload.get("message") or "Pengingat"
        if action_type == "quick_monthly_time":
            day = int(payload["day"])
            due = next_monthly_due(day, clock)
            schedule = schedule_payload(message, due, "monthly", recurrence_day=day)
        elif action_type == "quick_daily_time":
            due = next_daily_due(clock)
            schedule = schedule_payload(message, due, "daily")
        elif action_type == "quick_weekly_time":
            wd = int(payload["weekday"])
            due = next_weekly_due(wd, clock)
            schedule = schedule_payload(message, due, "weekly", recurrence_weekday=wd)
        else:
            d = date.fromisoformat(payload["date"])
            due = _combine_local(d, clock)
            if due <= datetime.now(JAKARTA):
                await gowa_send_text(jid, "⚠️ Waktu tersebut sudah lewat. Masukkan waktu yang akan datang.")
                return True
            schedule = schedule_payload(message, due, "once")
        await set_reminder_confirmation(jid, schedule)
        return True

    # Edit/delete reminder selection.
    if action_type in {"reminder_edit_pick", "reminder_delete_pick"}:
        try:
            idx = int(re.sub(r"[^0-9]", "", raw)) - 1
        except Exception:
            idx = -1
        ids = payload.get("ids") or []
        if idx < 0 or idx >= len(ids):
            await gowa_send_text(jid, f"⚠️ Pilih nomor 1–{len(ids)} atau 0.")
            return True
        reminder_id = ids[idx]
        row = await db.get_reminder(jid, reminder_id)
        if not row:
            await gowa_send_text(jid, "Pengingat sudah tidak tersedia.")
            await send_reminder_menu(jid)
            return True
        if action_type == "reminder_delete_pick":
            await db.set_pending_action(
                jid, "reminder_cancel",
                {"reminder_id": reminder_id, "message": row["message"]},
                ttl_minutes=20,
            )
            await gowa_send_text(
                jid,
                "🗑 *HAPUS PENGINGAT?*\n\n"
                f"📝 {row['message']}\n🗓 {recurrence_label(row)}\n\n"
                "1️⃣ HAPUS\n0️⃣ BATAL",
            )
        else:
            await db.set_pending_action(jid, "reminder_edit_menu", {"reminder_id": reminder_id}, ttl_minutes=20)
            await gowa_send_text(
                jid,
                "✏️ *EDIT PENGINGAT*\n\n"
                f"📝 {row['message']}\n🗓 {recurrence_label(row)}\n\n"
                "1️⃣ Edit Isi\n2️⃣ Edit Jadwal\n0️⃣ Kembali",
            )
        return True

    if action_type == "reminder_edit_menu":
        if choice == "1":
            await db.set_pending_action(jid, "reminder_edit_message_value", payload, ttl_minutes=20)
            await gowa_send_text(jid, "📝 Ketik isi pengingat yang baru.\n\n0️⃣ Batal")
            return True
        if choice == "2":
            current = await db.get_reminder(jid, payload["reminder_id"])
            edit_payload = {
                "reminder_id": payload["reminder_id"],
                "message": current["message"] if current else "Pengingat",
            }
            await db.set_pending_action(jid, "reminder_edit_type", edit_payload, ttl_minutes=20)
            await gowa_send_text(
                jid,
                "🗓 *JADWAL BARU*\n\n1️⃣ Sekali\n2️⃣ Setiap Hari\n3️⃣ Setiap Minggu\n4️⃣ Setiap Bulan\n\n0️⃣ Batal",
            )
            return True
        await gowa_send_text(jid, "⚠️ Pilih *1*, *2*, atau *0*.")
        return True

    if action_type == "reminder_edit_message_value":
        if len(raw) < 2:
            await gowa_send_text(jid, "Isi terlalu pendek.")
            return True
        await db.set_pending_action(
            jid, "reminder_message_update",
            {"reminder_id": payload["reminder_id"], "message": raw[:500]},
            ttl_minutes=20,
        )
        await gowa_send_text(jid, f"✏️ Ubah isi menjadi:\n*{raw[:500]}*\n\n1️⃣ SIMPAN\n0️⃣ BATAL")
        return True

    # Export menu + custom range.
    if action_type == "menu_export":
        options = {
            "1": ("EXPORT EXCEL", "⏳ Menyiapkan Excel bulan ini..."),
            "2": ("EXPORT PDF", "⏳ Menyiapkan PDF bulan ini..."),
            "3": ("EXPORT EXCEL SEMUA", "⏳ Menyiapkan Excel semua data..."),
            "4": ("EXPORT PDF SEMUA", "⏳ Menyiapkan PDF semua data..."),
        }
        if choice in options:
            command, notice = options[choice]
            await db.clear_pending_action(jid)
            await gowa_send_text(jid, notice)
            await handle_export(jid, command)
            return True
        if choice == "5":
            await db.set_pending_action(jid, "export_range_start", {}, ttl_minutes=20)
            await gowa_send_text(jid, "📅 Tanggal awal?\nFormat: *DD-MM-YYYY*\nContoh: `01-08-2026`")
            return True
        await gowa_send_text(jid, "⚠️ Pilih *1–5* atau *0*.")
        return True

    if action_type == "export_range_start":
        d = parse_date_input(raw)
        if not d:
            await gowa_send_text(jid, "⚠️ Tanggal awal tidak valid. Gunakan *DD-MM-YYYY*.")
            return True
        await db.set_pending_action(jid, "export_range_end", {"start": d.isoformat()}, ttl_minutes=20)
        await gowa_send_text(jid, "📅 Tanggal akhir?\nFormat: *DD-MM-YYYY*")
        return True

    if action_type == "export_range_end":
        d = parse_date_input(raw)
        start = date.fromisoformat(payload["start"])
        if not d or d < start:
            await gowa_send_text(jid, "⚠️ Tanggal akhir harus valid dan tidak boleh sebelum tanggal awal.")
            return True
        await db.set_pending_action(
            jid, "export_range_format",
            {"start": start.isoformat(), "end": d.isoformat()}, ttl_minutes=20
        )
        await gowa_send_text(jid, "📤 Pilih format:\n\n1️⃣ Excel\n2️⃣ PDF\n0️⃣ Batal")
        return True

    if action_type == "export_range_format":
        if choice not in {"1", "2"}:
            await gowa_send_text(jid, "⚠️ Pilih *1*, *2*, atau *0*.")
            return True
        start = date.fromisoformat(payload["start"])
        end = date.fromisoformat(payload["end"])
        await db.clear_pending_action(jid)
        await gowa_send_text(jid, "⏳ Menyiapkan laporan rentang tanggal...")
        await handle_export(jid, "EXPORT PDF" if choice == "2" else "EXPORT EXCEL", start, end)
        return True

    # Business/account menu.
    if action_type == "menu_business":
        if choice == "1":
            await db.set_pending_action(jid, "menu_business_rename", {}, ttl_minutes=20)
            await gowa_send_text(jid, "✏️ Ketik nama usaha baru.\nContoh: *Toko Jaya Elektronik*\n\n0️⃣ Batal")
            return True
        if choice == "2":
            await db.set_pending_action(jid, "menu_link_telegram", {"attempts": 0}, ttl_minutes=20)
            await gowa_send_text(
                jid,
                "🔗 *HUBUNGKAN TELEGRAM*\n\n"
                "1. Buka bot Telegram dengan akun user.\n"
                "2. Pilih *🔗 Hubungkan WhatsApp* atau ketik `/linkwa`.\n"
                "3. Masukkan kode 6 digit yang diberikan Telegram di sini.\n\n"
                "0️⃣ Batal",
            )
            return True
        await gowa_send_text(jid, "⚠️ Pilih *1*, *2*, atau *0*.")
        return True

    if action_type == "menu_business_rename":
        name = raw.strip()
        if len(name) < 2 or len(name) > 100:
            await gowa_send_text(jid, "Nama usaha harus 2–100 karakter.")
            return True
        await db.set_pending_action(jid, "rename_business", {"business_name": name}, ttl_minutes=20)
        await gowa_send_text(jid, f"✏️ Nama baru: *{name}*\n\n1️⃣ SIMPAN\n2️⃣ EDIT\n0️⃣ BATAL")
        return True

    if action_type == "menu_link_telegram":
        code = re.sub(r"[^0-9]", "", raw)
        if len(code) != 6:
            await gowa_send_text(jid, "⚠️ Kode harus *6 digit*. Masukkan ulang atau 0 untuk batal.")
            return True
        attempts = int(payload.get("attempts", 0)) + 1
        try:
            result = await db.link_whatsapp_to_telegram(jid, code)
        except LookupError:
            if attempts >= 5:
                await db.clear_pending_action(jid)
                await gowa_send_text(jid, "❌ Kode salah/kedaluwarsa terlalu banyak kali. Buat kode baru dari Telegram.\n\n0️⃣ Menu Utama")
            else:
                await db.set_pending_action(jid, "menu_link_telegram", {"attempts": attempts}, ttl_minutes=20)
                await gowa_send_text(jid, f"❌ Kode salah atau kedaluwarsa. Sisa percobaan: {5-attempts}.")
            return True
        except ValueError as exc:
            code_name = str(exc)
            if "WA_ACCOUNT_HAS_DATA" in code_name:
                msg = "⚠️ Akun WhatsApp ini sudah memiliki transaksi/pengingat sendiri. Penyatuan otomatis diblokir agar tidak mencampur data. Hubungi MASTER untuk migrasi aman."
            elif "TARGET_ALREADY_HAS_WHATSAPP" in code_name:
                msg = "⚠️ Akun Telegram tersebut sudah terhubung dengan nomor WhatsApp lain."
            else:
                msg = "⚠️ Akun belum dapat dihubungkan secara otomatis."
            await gowa_send_text(jid, msg + "\n\n0️⃣ Menu Utama")
            return True
        await db.clear_pending_action(jid)
        await gowa_send_text(
            jid,
            "✅ *AKUN BERHASIL DIHUBUNGKAN*\n\n"
            f"👤 {result.get('full_name') or '-'}\n"
            f"🏪 {result.get('business_name') or '-'}\n\n"
            "Sekarang Telegram dan WhatsApp memakai user/tenant yang sama.\n\n0️⃣ Menu Utama",
        )
        return True

    if action_type == "menu_ai":
        await db.clear_pending_action(jid)
        await handle_ai(jid, raw)
        return True

    if action_type == "menu_pos":
        await db.clear_pending_action(jid)
        await handle_pos_command(jid, raw if raw.lower().startswith("pos") else f"POS {raw}")
        return True

    return False

async def handle_main_choice(jid: str, text: str) -> bool:
    choice = first_choice(text)
    if choice is None:
        return False
    access = await db.get_whatsapp_access(jid)
    required = {
        "1": "finance.write", "2": "finance.write", "3": "finance.read",
        "5": "finance.export", "9": "pos.read",
    }.get(choice)
    if required and (not access or not has_permission(access["role"], required)):
        await gowa_send_text(jid, f"⛔ Role {access['role'] if access else '-'} tidak memiliki izin {required}.\n\n0️⃣ Menu Utama")
        return True
    if choice == "0":
        await send_main_menu(jid); return True
    if choice == "1":
        await start_guided_transaction(jid, "income"); return True
    if choice == "2":
        await start_guided_transaction(jid, "expense"); return True
    if choice == "3":
        await send_summary(jid); return True
    if choice == "4":
        await send_reminder_menu(jid); return True
    if choice == "5":
        await send_export_menu(jid); return True
    if choice == "6":
        await db.set_pending_action(jid, "menu_ai", {}, ttl_minutes=20)
        await gowa_send_text(jid, "🤖 *ASISTEN AI*\n\nTulis dengan bahasa biasa.\nContoh:\n• *jual 2 KOPI bayar QRIS*\n• *berapa stok KOPI?*\n• *laporan POS hari ini*\n• *bagaimana kondisi keuangan bulan ini?*\n\nAksi tulis hasil AI selalu meminta konfirmasi.\n\n0️⃣ Kembali")
        return True
    if choice == "7":
        await send_business_menu(jid); return True
    if choice == "8":
        await gowa_send_text(jid, help_examples()); return True
    if choice == "9":
        await send_pos_menu(jid); return True
    return False

async def pending_response(jid: str, access):
    status = access["access_status"]
    if status == "pending":
        if access["master_notified_at"] is None:
            try:
                await telegram_notify_master(
                    "🟢 USER WHATSAPP BARU\n\n"
                    f"Nama: {access['display_name'] or '-'}\n"
                    f"WhatsApp: {access['phone_number'] or access['whatsapp_jid']}\n"
                    "Status: PENDING\n\n"
                    "Buka menu ⏳ User Pending pada Telegram MASTER, "
                    "lalu pilih ✅ Setujui dan tentukan nama usaha."
                )
                await db.mark_master_notified(jid)
            except Exception:
                log.exception("Gagal mengirim notifikasi pending ke MASTER")

        await gowa_send_text(
            jid,
            "⏳ AKSES BELUM DISETUJUI\n\n"
            "Nomor WhatsApp Anda sudah tercatat, tetapi belum dapat "
            "menggunakan fitur Asisten UMKM.\n\n"
            "Administrator harus menyetujui akun dan menentukan nama usaha "
            "terlebih dahulu.\n\n"
            f"Nomor terdaftar: {access['phone_number'] or '-'}",
        )
    elif status == "suspended":
        await gowa_send_text(
            jid,
            "⛔ Akses Anda sedang dinonaktifkan oleh administrator.",
        )
    else:
        await gowa_send_text(
            jid,
            "🚫 Akses akun ini tidak tersedia. Hubungi administrator.",
        )


async def handle_confirmation(jid: str, text: str) -> bool:
    pending = await db.get_pending_action(jid)
    if not pending:
        return False
    action_type = pending["action_type"]
    if action_type.startswith(("menu_", "guided_", "quick_", "export_")):
        return False
    if action_type in {
        "reminder_type", "reminder_message", "reminder_once_date",
        "reminder_weekday", "reminder_monthday", "reminder_time",
        "reminder_edit_pick", "reminder_delete_pick", "reminder_edit_menu",
        "reminder_edit_type", "reminder_edit_message_value",
    }:
        return False

    normalized = text.strip().lower().replace("1️⃣", "1").replace("2️⃣", "2").replace("0️⃣", "0")
    save_values = {"simpan", "save", "ya", "yes", "1", "hapus"}
    edit_values = {"edit", "ubah", "2"}
    cancel_values = {"batal", "cancel", "tidak", "no", "0"}

    if normalized in cancel_values:
        await db.clear_pending_action(jid)
        await gowa_send_text(jid, "❌ Tindakan dibatalkan.\n\n0️⃣ Menu Utama")
        return True

    payload = json_object(pending["payload"])

    if normalized in edit_values:
        if action_type == "transaction":
            await start_guided_transaction(jid, "income" if payload.get("tx_type") == "income" else "expense")
            return True
        if action_type in {"reminder", "reminder_schedule_update"}:
            if action_type == "reminder_schedule_update":
                await db.set_pending_action(jid, "reminder_edit_type", {"reminder_id": payload["reminder_id"]}, ttl_minutes=20)
                await gowa_send_text(jid, "🗓 Pilih jadwal baru:\n1️⃣ Sekali\n2️⃣ Harian\n3️⃣ Mingguan\n4️⃣ Bulanan\n0️⃣ Batal")
            else:
                await send_reminder_menu(jid)
            return True
        if action_type == "rename_business":
            await db.set_pending_action(jid, "menu_business_rename", {}, ttl_minutes=20)
            await gowa_send_text(jid, "✏️ Ketik kembali nama usaha.\n\n0️⃣ Batal")
            return True

    if normalized not in save_values:
        await gowa_send_text(jid, "⚠️ Pilihan belum dikenali.\n\n1️⃣ SIMPAN\n2️⃣ EDIT\n0️⃣ BATAL")
        return True

    if action_type == "pos_sale":
        try:
            _, sale, repeated = await pos.create_sale(
                jid,
                payload.get("items") or [],
                payload.get("payment_method") or "",
                "whatsapp",
                str(uuid.uuid4()),
            )
        except (PermissionDenied, PermissionError, ValueError, LookupError) as exc:
            await db.clear_pending_action(jid)
            await gowa_send_text(jid, f"⚠️ Penjualan gagal: {exc}\n\n0️⃣ Menu Utama")
            return True
        await db.clear_pending_action(jid)
        await gowa_send_text(jid, f"✅ *PENJUALAN TERSIMPAN*\nInvoice: `{sale['invoice_no']}`\nTotal: *{rupiah(sale['total'])}*\nStok dan pemasukan telah diperbarui.\n\n0️⃣ Menu Utama")
        return True

    if action_type == "transaction":
        row = await db.create_transaction(
            jid, payload["tx_type"], int(payload["amount"]),
            payload.get("description") or "Transaksi", payload.get("category") or "Umum"
        )
        await db.clear_pending_action(jid)
        label = "Pemasukan" if row["type"] == "income" else "Pengeluaran"
        await gowa_send_text(jid, f"✅ *TRANSAKSI TERSIMPAN*\n\n{label}: *{rupiah(int(row['amount']))}*\nKategori: {row['category']}\nKeterangan: {row['description']}\n\n1️⃣ Pemasukan\n2️⃣ Pengeluaran\n3️⃣ Ringkasan\n0️⃣ Menu")
        return True

    if action_type == "reminder":
        due_local = datetime.fromisoformat(payload["reminder_at"])
        if due_local.tzinfo is None:
            due_local = due_local.replace(tzinfo=JAKARTA)
        due_local = due_local.astimezone(JAKARTA)
        recurrence_time = dt_time.fromisoformat(payload.get("recurrence_time") or due_local.strftime("%H:%M:%S"))
        row = await db.create_reminder(
            jid,
            payload["message"],
            due_local.astimezone(UTC),
            payload.get("recurrence_type", "once"),
            int(payload.get("recurrence_interval", 1)),
            payload.get("recurrence_day"),
            payload.get("recurrence_weekday"),
            recurrence_time,
        )
        await db.clear_pending_action(jid)
        await gowa_send_text(jid, f"✅ *PENGINGAT DIBUAT*\n\n📝 {row['message']}\n🗓 {recurrence_label(row)}\n🔔 Berikutnya: {row['due_at'].astimezone(JAKARTA).strftime('%d-%m-%Y %H:%M')} WIB\n\n4️⃣ Kelola Pengingat\n0️⃣ Menu")
        return True

    if action_type == "reminder_schedule_update":
        due_local = datetime.fromisoformat(payload["reminder_at"]).astimezone(JAKARTA)
        recurrence_time = dt_time.fromisoformat(payload.get("recurrence_time") or due_local.strftime("%H:%M:%S"))
        row = await db.update_reminder_schedule(
            jid, payload["reminder_id"], due_local.astimezone(UTC),
            payload.get("recurrence_type", "once"),
            int(payload.get("recurrence_interval", 1)),
            payload.get("recurrence_day"), payload.get("recurrence_weekday"),
            recurrence_time,
        )
        await db.clear_pending_action(jid)
        await gowa_send_text(jid, f"✅ *JADWAL DIPERBARUI*\n\n📝 {row['message']}\n🗓 {recurrence_label(row)}\n\n4️⃣ Kelola Pengingat\n0️⃣ Menu")
        return True

    if action_type == "reminder_message_update":
        row = await db.update_reminder_message(jid, payload["reminder_id"], payload["message"])
        await db.clear_pending_action(jid)
        await gowa_send_text(jid, f"✅ *ISI PENGINGAT DIPERBARUI*\n\n📝 {row['message']}\n\n4️⃣ Kelola Pengingat\n0️⃣ Menu")
        return True

    if action_type == "reminder_cancel":
        row = await db.cancel_reminder(jid, payload["reminder_id"])
        await db.clear_pending_action(jid)
        await gowa_send_text(jid, f"🗑 *PENGINGAT DIHAPUS*\n\n{row['message']}\n\n4️⃣ Kelola Pengingat\n0️⃣ Menu")
        return True

    if action_type == "rename_business":
        new_name = await db.rename_business(jid, payload["business_name"])
        await db.clear_pending_action(jid)
        await gowa_send_text(jid, f"✅ *NAMA USAHA DIPERBARUI*\n\n🏪 {new_name}\n\n7️⃣ Pengaturan & Akun\n0️⃣ Menu")
        return True

    await db.clear_pending_action(jid)
    await gowa_send_text(jid, "⚠️ Tindakan lama tidak dikenali dan dibatalkan.\n\n0️⃣ Menu Utama")
    return True

async def send_summary(jid: str):
    ctx, totals = await db.monthly_summary(jid)
    income = totals["income"]
    expense = totals["expense"]
    balance = income - expense
    await gowa_send_text(
        jid,
        "📊 *RINGKASAN BULAN INI*\n"
        f"🏪 {ctx['business_name']}\n\n"
        f"💰 Pemasukan: *{rupiah(income)}*\n"
        f"💸 Pengeluaran: *{rupiah(expense)}*\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"💵 Selisih: *{rupiah(balance)}*\n\n"
        "5️⃣ Export Laporan\n"
        "6️⃣ Tanya AI\n"
        "0️⃣ Menu Utama",
    )


def current_month_range():
    today = datetime.now(JAKARTA).date()
    start = today.replace(day=1)
    if today.month == 12:
        next_month = date(today.year + 1, 1, 1)
    else:
        next_month = date(today.year, today.month + 1, 1)
    end = next_month - timedelta(days=1)
    return start, end


async def handle_export(
    jid: str,
    text: str,
    custom_start: date | None = None,
    custom_end: date | None = None,
):
    lower = text.lower()
    fmt = "pdf" if "pdf" in lower else "xlsx"
    all_data = "semua" in lower or "all" in lower

    if custom_start and custom_end:
        start_date, end_date = custom_start, custom_end
        period = f"{start_date.strftime('%d-%m-%Y')} s.d. {end_date.strftime('%d-%m-%Y')}"
    elif all_data:
        start_date = None
        end_date = None
        period = "Semua Data"
    else:
        start_date, end_date = current_month_range()
        period = datetime.now(JAKARTA).strftime("%B %Y")

    ctx, rows = await db.finance_export_data(jid, start_date, end_date)
    generated_at = datetime.now(JAKARTA)
    if fmt == "pdf":
        path = exporter.build_pdf_report(ctx["business_name"], period, generated_at, rows)
        label = "PDF"
    else:
        path = exporter.build_excel_report(ctx["business_name"], period, generated_at, rows)
        label = "Excel"
    try:
        await gowa_send_file(
            jid, path,
            f"Laporan Keuangan - {ctx['business_name']}\nPeriode: {period}\nFormat: {label}\nJumlah transaksi: {len(rows)}",
        )
        await db.log_finance_export(jid, label.lower(), period, len(rows))
    finally:
        exporter.remove_export(path)

async def handle_ai(jid: str, text: str):
    if not ai.is_configured():
        await gowa_send_text(
            jid,
            "🤖 Asisten AI belum dikonfigurasi oleh administrator.\n"
            "Fitur dasar tetap dapat digunakan.\n\n"
            "3️⃣ Ringkasan Keuangan\n"
            "5️⃣ Export Laporan\n"
            "7️⃣ Pengaturan Usaha\n"
            "0️⃣ Menu Utama",
        )
        return

    provider = ai.PROVIDER
    model = ai.MODEL

    await gowa_chat_presence(jid, "start")
    try:
        access = await db.get_whatsapp_access(jid)
        if access and has_permission(access["role"], "finance.read"):
            finance_context = await db.ai_finance_context(jid)
        else:
            finance_context = {
                "business_name": access["business_name"] if access else "-",
                "role": access["role"] if access else "-",
                "month_income": None, "month_expense": None, "month_balance": None,
                "recent_transactions": [], "active_reminders": [],
            }
        result = await ai.analyze_message(
            text,
            finance_context,
            datetime.now(JAKARTA).isoformat(),
        )
        await db.log_ai_usage(
            jid,
            provider,
            result.model,
            result.intent,
            result.prompt_tokens,
            result.completion_tokens,
            result.total_tokens,
            True,
            None,
        )
        await gowa_chat_presence(jid, "stop")
    except Exception as exc:
        await gowa_chat_presence(jid, "stop")
        log.exception("AI gagal")
        try:
            await db.log_ai_usage(
                jid,
                provider,
                model,
                "service_error",
                success=False,
                error_code=str(exc)[:120],
            )
        except Exception:
            pass
        await gowa_send_text(
            jid,
            "⚠️ Layanan AI sedang tidak dapat digunakan. Coba lagi beberapa saat.\n\n"
            "3️⃣ Ringkasan Keuangan\n"
            "0️⃣ Menu Utama",
        )
        return

    if result.needs_clarification:
        await gowa_send_text(
            jid,
            (result.clarification or "Mohon lengkapi informasi yang diperlukan.")
            + "\n\n0️⃣ Menu Utama",
        )
        return

    if result.intent in {"create_income", "create_expense"}:
        if not access or not has_permission(access["role"], "finance.write"):
            await gowa_send_text(jid, "⛔ Role Anda tidak boleh menulis transaksi keuangan manual.\n\n0️⃣ Menu Utama")
            return
        tx_type = "income" if result.intent == "create_income" else "expense"
        description = result.description or (
            "Pemasukan" if tx_type == "income" else "Pengeluaran"
        )
        category = result.category or "Umum"

        await db.set_pending_action(
            jid,
            "transaction",
            {
                "tx_type": tx_type,
                "amount": result.amount,
                "description": description,
                "category": category,
            },
        )
        label = "PEMASUKAN" if tx_type == "income" else "PENGELUARAN"
        await gowa_send_text(
            jid,
            "🤖 KONFIRMASI TRANSAKSI\n\n"
            f"🧾 {label}\n"
            f"Nominal: {rupiah(result.amount)}\n"
            f"Kategori: {category}\n"
            f"Keterangan: {description}\n\n"
            "1️⃣ SIMPAN\n2️⃣ EDIT\n0️⃣ BATAL",
        )
        return

    if result.intent == "create_reminder":
        try:
            due_local = datetime.fromisoformat(result.reminder_at)
            if due_local.tzinfo is None:
                due_local = due_local.replace(tzinfo=JAKARTA)
            due_local = due_local.astimezone(JAKARTA)
        except Exception:
            await gowa_send_text(
                jid,
                "Saya memahami Anda ingin membuat pengingat, "
                "tetapi tanggal/jam belum valid. Tuliskan waktunya lebih jelas.",
            )
            return

        if due_local <= datetime.now(JAKARTA):
            await gowa_send_text(
                jid,
                "Waktu pengingat tersebut sudah lewat. Gunakan waktu yang akan datang.",
            )
            return

        reminder_message = result.reminder_message or result.description or text[:500]
        await db.set_pending_action(
            jid,
            "reminder",
            {
                "message": reminder_message,
                "reminder_at": due_local.isoformat(),
            },
        )
        await gowa_send_text(
            jid,
            "🤖 KONFIRMASI PENGINGAT\n\n"
            f"📝 {reminder_message}\n"
            f"🗓 {due_local.strftime('%d-%m-%Y %H:%M')} WIB\n\n"
            "1️⃣ SIMPAN\n2️⃣ EDIT\n0️⃣ BATAL",
        )
        return

    if result.intent == "finance_summary":
        if not access or not has_permission(access["role"], "finance.read"):
            await gowa_send_text(jid, "⛔ Role Anda tidak boleh melihat ringkasan keuangan.\n\n0️⃣ Menu Utama")
            return
        await send_summary(jid)
        return

    if result.intent == "finance_question" and (not access or not has_permission(access["role"], "finance.read")):
        await gowa_send_text(jid, "⛔ Role Anda tidak boleh mengakses data keuangan.\n\n0️⃣ Menu Utama")
        return

    if result.intent == "create_sale":
        if not access or not has_permission(access["role"], "pos.sell"):
            await gowa_send_text(jid, "⛔ Role Anda tidak boleh mencatat penjualan POS.\n\n0️⃣ Menu Utama")
            return
        items = result.sale_items or []
        await db.set_pending_action(jid, "pos_sale", {"items": items, "payment_method": result.payment_method}, ttl_minutes=10)
        item_text = ", ".join(f"{x.get('sku','')} × {x.get('qty','')}" for x in items)
        await gowa_send_text(jid, f"🤖 *KONFIRMASI PENJUALAN POS*\n\nItem: {item_text}\nBayar: *{result.payment_method}*\n\nHarga dan stok akan divalidasi database.\n\n1️⃣ SIMPAN\n0️⃣ BATAL")
        return

    if result.intent == "stock_query":
        try:
            _, product = await pos.get_product(jid, result.product_sku or "")
        except (PermissionDenied, PermissionError, ValueError, LookupError) as exc:
            await gowa_send_text(jid, f"⚠️ {exc}\n\n0️⃣ Menu Utama")
            return
        if not product:
            await gowa_send_text(jid, "Produk tidak ditemukan.\n\n0️⃣ Menu Utama")
        else:
            await gowa_send_text(jid, f"📦 `{product['sku']}` — *{product['name']}*\nStok: *{_qty(product['stock_on_hand'])} {product['unit']}*\nHarga: *{rupiah(product['sell_price'])}*\n\n0️⃣ Menu Utama")
        return

    if result.intent == "pos_summary":
        try:
            ctx, row, low = await pos.pos_summary(jid, date.today(), date.today())
        except (PermissionDenied, PermissionError, ValueError, LookupError) as exc:
            await gowa_send_text(jid, f"⛔ {exc}\n\n0️⃣ Menu Utama")
            return
        await gowa_send_text(jid, f"📊 *POS HARI INI*\n🏪 {ctx['business_name']}\nTransaksi: *{row['sales_count']}*\nOmzet: *{rupiah(row['revenue'])}*\nLaba kotor: *{rupiah(row['gross_profit'])}*\nStok rendah: *{low}*\n\n0️⃣ Menu Utama")
        return

    if result.intent in {"finance_question", "general_question"}:
        await gowa_send_text(
            jid,
            (result.answer or "Saya belum memiliki jawaban yang cukup.")
            + "\n\n━━━━━━━━━━━━━━━━━━\n"
            "6️⃣ Tanya AI lagi\n"
            "3️⃣ Ringkasan Keuangan\n"
            "0️⃣ Menu Utama",
        )
        return

    message = (
        result.clarification
        or result.answer
        or (
            "Saya belum memahami permintaan itu.\n"
            "Contoh: “catat pemasukan 50rb”, “keluar 25rb parkir”, "
            "atau “berapa pengeluaran bulan ini?”"
        )
    )
    await gowa_send_text(
        jid,
        message
        + "\n\n━━━━━━━━━━━━━━━━━━\n"
        "8️⃣ Bantuan & Contoh\n"
        "0️⃣ Menu Utama",
    )


async def process_message(jid: str, payload: dict):
    display_name = payload.get("sender_display_name") or payload.get("from_name") or jid.split("@", 1)[0]
    access = await db.ensure_whatsapp_user(jid, payload.get("from_lid"), display_name)

    if access["access_status"] != "active" or access["deleted_at"] is not None:
        await pending_response(jid, access)
        return
    if not access["active_tenant_id"]:
        await gowa_send_text(jid, "⚠️ Akun sudah aktif tetapi belum memiliki usaha. Hubungi administrator.")
        return

    text = str(payload.get("body") or "").strip()
    if not text:
        await gowa_send_text(jid, "Kirim *MENU* untuk melihat fitur yang tersedia.")
        return

    # Navigation words override any current state; digits remain state-aware.
    nav = navigation_alias(text)
    if nav is not None:
        await db.clear_pending_action(jid)
        if nav == "0":
            await send_main_menu(jid)
        else:
            await handle_main_choice(jid, nav)
        return

    # Perintah aplikasi yang jelas tetap menang ketika user sedang berada di mode AI.
    current_state = await db.get_pending_action(jid)
    if current_state and current_state["action_type"] == "menu_ai":
        lower_pre = text.lower().strip()
        if re.search(r"pengingat.{0,20}(aktif|saya)|daftar\s+pengingat", lower_pre):
            await db.clear_pending_action(jid)
            await send_active_reminders(jid, "view")
            return
        if re.match(r"(?i)^\s*(buatkan\s+)?pengingat\b|^\s*ingatkan\b", text):
            await db.clear_pending_action(jid)
            if await try_quick_reminder(jid, text):
                return
        if re.match(r"(?i)^export\b", text):
            await db.clear_pending_action(jid)
            if any(x in lower_pre for x in {"excel", "xlsx", "pdf"}):
                await gowa_send_text(jid, "⏳ Menyiapkan laporan keuangan...")
                await handle_export(jid, text)
            else:
                await send_export_menu(jid)
            return

    if await handle_menu_state(jid, text):
        return
    if await handle_confirmation(jid, text):
        return
    if await handle_main_choice(jid, text):
        return

    lower = text.lower().strip()

    if lower == "pos" or lower.startswith("pos "):
        await db.clear_pending_action(jid)
        await handle_pos_command(jid, text)
        return

    if re.search(r"pengingat.{0,20}(aktif|saya)|daftar\s+pengingat", lower):
        await send_active_reminders(jid, "view")
        return

    if await try_quick_reminder(jid, text):
        return

    if lower in {"menu", "/menu", "start", "/start", "help", "bantuan", "halo", "hai", "hi"}:
        await send_main_menu(jid)
        return

    if re.match(r"(?i)^ubah\s+usaha\s+(.+)$", text):
        new_name = re.match(r"(?i)^ubah\s+usaha\s+(.+)$", text).group(1).strip()
        if len(new_name) < 2 or len(new_name) > 100:
            await gowa_send_text(jid, "Nama usaha harus 2–100 karakter.")
            return
        await db.set_pending_action(jid, "rename_business", {"business_name": new_name}, ttl_minutes=20)
        await gowa_send_text(jid, f"✏️ Nama baru: *{new_name}*\n\n1️⃣ SIMPAN\n2️⃣ EDIT\n0️⃣ BATAL")
        return

    if re.match(r"(?i)^export(\s+(excel|xlsx|pdf))?(\s+semua)?$", text):
        if not any(x in lower for x in {"excel", "xlsx", "pdf"}):
            await send_export_menu(jid)
            return
        await gowa_send_text(jid, "⏳ Menyiapkan laporan keuangan...")
        await handle_export(jid, text)
        return

    await handle_ai(jid, text)

async def event_worker():
    while True:
        try:
            event = await db.claim_next_event()
            if not event:
                await asyncio.sleep(1)
                continue
            try:
                payload = json_object(event["payload"])
                await process_message(event["whatsapp_jid"], payload)
                await db.mark_event_done(event["message_id"])
            except Exception as exc:
                log.exception("Gagal memproses WA event %s", event["message_id"])
                await db.mark_event_failed(
                    event["message_id"],
                    event["attempts"],
                    str(exc),
                )
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("WA event worker error")
            await asyncio.sleep(3)


async def reminder_worker():
    while True:
        try:
            rows = await db.claim_due_reminders(20)
            for row in rows:
                try:
                    local_due = row["due_at"].astimezone(JAKARTA)
                    await gowa_send_text(
                        row["whatsapp_jid"],
                        "🔔 PENGINGAT\n\n"
                        f"{row['message']}\n\n"
                        f"🗓 {local_due.strftime('%d-%m-%Y %H:%M')} WIB",
                    )
                    await db.mark_reminder_sent(row["reminder_id"])
                except Exception:
                    log.exception("Gagal mengirim reminder WA %s", row["reminder_id"])
            await asyncio.sleep(20)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("WA reminder worker error")
            await asyncio.sleep(10)


@app.on_event("startup")
async def startup():
    global _worker_task, _reminder_task
    await db.init_pool()
    _worker_task = asyncio.create_task(event_worker())
    _reminder_task = asyncio.create_task(reminder_worker())
    log.info("UMKM WhatsApp bridge started")


@app.on_event("shutdown")
async def shutdown():
    for task in (_worker_task, _reminder_task):
        if task:
            task.cancel()
    await db.close_pool()


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "umkm-gowa-bridge",
        "ai": ai.public_status(),
    }


@app.post("/webhooks/gowa")
async def gowa_webhook(request: Request):
    raw = await request.body()
    signature = request.headers.get("X-Hub-Signature-256")
    if not verify_signature(raw, signature):
        raise HTTPException(status_code=401, detail="invalid webhook signature")

    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="invalid json")

    if data.get("event") != "message":
        return {"ok": True, "ignored": "event"}

    payload = data.get("payload") or {}

    if payload.get("is_from_me") is True:
        return {"ok": True, "ignored": "from_me"}

    chat_id = normalize_jid(payload.get("chat_id"))
    sender = normalize_jid(payload.get("from"))

    if chat_id.endswith("@g.us"):
        return {"ok": True, "ignored": "group"}

    jid = sender if sender.endswith("@s.whatsapp.net") else chat_id
    if not jid or jid.endswith("@g.us"):
        return {"ok": True, "ignored": "unsupported_sender"}

    message_id = str(payload.get("id") or "").strip()
    if not message_id:
        raise HTTPException(status_code=400, detail="missing message id")

    inserted = await db.enqueue_event(message_id, jid, payload)
    return {"ok": True, "queued": bool(inserted)}
