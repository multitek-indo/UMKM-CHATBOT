"""Telegram command surface for UMKM Suite POS."""
from datetime import date
from decimal import Decimal
import html
import re
import uuid

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import Message

from app import db, pos
from app.permissions import PermissionDenied
from app.pos_parser import (
    parse_nonnegative_decimal, parse_nonnegative_money, parse_pipe_fields,
    parse_sale_items,
)


router = Router(name="pos-v070")


def rupiah(value) -> str:
    return "Rp{:,.0f}".format(Decimal(value or 0)).replace(",", ".")


def qty(value) -> str:
    return f"{Decimal(value):f}".rstrip("0").rstrip(".") or "0"


def payload(message: Message, command: str) -> str:
    return re.sub(rf"^/{re.escape(command)}(?:@\w+)?\s*", "", message.text or "", flags=re.I).strip()


async def active_identity(message: Message):
    tg = message.from_user
    await db.ensure_user(tg.id, tg.full_name if tg else None)
    access = await db.get_access(tg.id)
    if access["is_master"]:
        await message.answer("Masuk ke salah satu user melalui menu 🛠 Login User sebelum membuka POS.")
        return None
    if access["access_status"] != "active" or not access["active_tenant_id"]:
        await message.answer("Akun belum aktif atau belum memiliki usaha.")
        return None
    return tg.id


async def run(message: Message, action):
    identity = await active_identity(message)
    if identity is None:
        return None
    try:
        return await action(identity)
    except PermissionDenied as exc:
        await message.answer(f"⛔ {html.escape(str(exc))}")
    except PermissionError as exc:
        await message.answer(f"⛔ {html.escape(str(exc))}")
    except (ValueError, LookupError) as exc:
        await message.answer(f"⚠️ {html.escape(str(exc))}")
    return None


POS_HELP = """🛒 <b>UMKM POS v0.7.0</b>

Transaksi:
<code>/sale KOPI:2,ROTI:1 | QRIS</code>
<code>/sale_void POS-YYYYMMDD-00001 | Alasan</code> (OWNER/ADMIN)
<code>/products</code> · <code>/stock_low</code> · <code>/pos_report today</code>

Produk & stok (OWNER/ADMIN/INVENTORY):
<code>/product_add SKU | Nama | Harga jual | Harga modal | Stok awal | Satuan | Stok minimum</code>
<code>/product_edit SKU | Nama | Harga jual | Harga modal | Satuan | Stok minimum</code>
<code>/product_off SKU</code>
<code>/stock SKU | Stok baru | Alasan</code>

Stock opname:
<code>/opname_start Catatan</code>
<code>/opname_count SKU | Jumlah fisik</code>
<code>/opname_post</code>

Staf (OWNER/ADMIN):
<code>/staff_list</code>
<code>/staff_add TELEGRAM_ID | Nama | ROLE</code>
<code>/staff_role TELEGRAM_ID | ROLE</code>
<code>/staff_remove TELEGRAM_ID</code>
ROLE: ADMIN, FINANCE, CASHIER, INVENTORY, VIEWER."""


@router.message(Command("pos"))
@router.message(F.text == "🛒 POS & Stok")
async def pos_help(message: Message):
    if await active_identity(message) is not None:
        await message.answer(POS_HELP, parse_mode="HTML")


@router.message(Command("products"))
async def products(message: Message):
    result = await run(message, lambda ident: pos.list_products(ident))
    if not result:
        return
    ctx, rows = result
    if not rows:
        await message.answer("Belum ada produk. Gunakan /product_add.")
        return
    lines = [f"📦 <b>Produk · {html.escape(ctx['business_name'])}</b>"]
    for row in rows:
        marker = " ⚠️" if row["stock_on_hand"] <= row["min_stock"] else ""
        lines.append(f"• <code>{row['sku']}</code> — {html.escape(row['name'])} · {qty(row['stock_on_hand'])} {html.escape(row['unit'])} · {rupiah(row['sell_price'])}{marker}")
    await message.answer("\n".join(lines), parse_mode="HTML")


@router.message(Command("stock_low"))
async def stock_low(message: Message):
    result = await run(message, lambda ident: pos.list_products(ident, low_stock_only=True))
    if not result:
        return
    _, rows = result
    if not rows:
        await message.answer("✅ Tidak ada stok yang menyentuh batas minimum.")
        return
    await message.answer("⚠️ <b>Stok rendah</b>\n" + "\n".join(
        f"• <code>{r['sku']}</code> {html.escape(r['name'])}: {qty(r['stock_on_hand'])} / min {qty(r['min_stock'])}"
        for r in rows
    ), parse_mode="HTML")


@router.message(Command("product_add"))
async def product_add(message: Message):
    try:
        sku, name, sell, cost, opening, unit, minimum = parse_pipe_fields(payload(message, "product_add"), 7)
        values = (sku, name, parse_nonnegative_money(sell), parse_nonnegative_money(cost),
                  parse_nonnegative_decimal(opening), unit, parse_nonnegative_decimal(minimum))
    except ValueError as exc:
        await message.answer(f"⚠️ {html.escape(str(exc))}\nContoh: <code>/product_add KOPI | Kopi Susu | 18000 | 9000 | 20 | cup | 5</code>", parse_mode="HTML")
        return
    result = await run(message, lambda ident: pos.add_product(ident, *values))
    if result:
        _, row = result
        await message.answer(f"✅ Produk <code>{row['sku']}</code> tersimpan. Stok {qty(row['stock_on_hand'])}, harga {rupiah(row['sell_price'])}.", parse_mode="HTML")


@router.message(Command("product_edit"))
async def product_edit(message: Message):
    try:
        sku, name, sell, cost, unit, minimum = parse_pipe_fields(payload(message, "product_edit"), 6)
        values = dict(name=name, sell_price=parse_nonnegative_money(sell), cost_price=parse_nonnegative_money(cost), unit=unit, min_stock=parse_nonnegative_decimal(minimum))
    except ValueError as exc:
        await message.answer(f"⚠️ {html.escape(str(exc))}")
        return
    result = await run(message, lambda ident: pos.update_product(ident, sku, **values))
    if result:
        _, row = result
        await message.answer(f"✅ Produk <code>{row['sku']}</code> diperbarui.", parse_mode="HTML")


@router.message(Command("product_off"))
async def product_off(message: Message):
    result = await run(message, lambda ident: pos.deactivate_product(ident, payload(message, "product_off")))
    if result:
        _, row = result
        await message.answer(f"✅ Produk <code>{row['sku']}</code> dinonaktifkan.", parse_mode="HTML")


@router.message(Command("stock"))
async def stock_set(message: Message):
    try:
        sku, amount, note = parse_pipe_fields(payload(message, "stock"), 3)
        new_stock = parse_nonnegative_decimal(amount)
    except ValueError as exc:
        await message.answer(f"⚠️ {html.escape(str(exc))}\nContoh: <code>/stock KOPI | 24 | Hasil hitung gudang</code>", parse_mode="HTML")
        return
    result = await run(message, lambda ident: pos.set_stock(ident, sku, new_stock, note))
    if result:
        _, row, delta = result
        delta_text = qty(delta)
        if Decimal(delta) > 0:
            delta_text = "+" + delta_text
        await message.answer(f"✅ Stok <code>{row['sku']}</code> = {qty(row['stock_on_hand'])} ({delta_text} perubahan).", parse_mode="HTML")


@router.message(Command("sale"))
async def sale(message: Message):
    try:
        raw_items, payment = parse_pipe_fields(payload(message, "sale"), 2)
        items = parse_sale_items(raw_items)
    except ValueError as exc:
        await message.answer(f"⚠️ {html.escape(str(exc))}\nContoh: <code>/sale KOPI:2,ROTI:1 | QRIS</code>", parse_mode="HTML")
        return
    key = str(uuid.uuid4())
    result = await run(message, lambda ident: pos.create_sale(ident, items, payment, "telegram", key))
    if result:
        _, row, repeated = result
        suffix = " (duplikat aman)" if repeated else ""
        await message.answer(f"✅ <b>Penjualan tercatat</b>{suffix}\nInvoice: <code>{row['invoice_no']}</code>\nTotal: <b>{rupiah(row['total'])}</b>\nBayar: {row['payment_method']}\nStok dan pemasukan sudah diperbarui atomik.", parse_mode="HTML")


@router.message(Command("pos_report"))
async def pos_report(message: Message):
    mode = payload(message, "pos_report").lower() or "today"
    if mode not in {"today", "month"}:
        await message.answer("Gunakan <code>/pos_report today</code> atau <code>/pos_report month</code>.", parse_mode="HTML")
        return
    today = date.today()
    start = today if mode == "today" else today.replace(day=1)
    result = await run(message, lambda ident: pos.pos_summary(ident, start, today))
    if result:
        ctx, row, low = result
        await message.answer(f"📊 <b>Laporan POS · {html.escape(ctx['business_name'])}</b>\nPeriode: {start:%d-%m-%Y} s.d. {today:%d-%m-%Y}\nTransaksi: <b>{row['sales_count']}</b>\nOmzet: <b>{rupiah(row['revenue'])}</b>\nLaba kotor: <b>{rupiah(row['gross_profit'])}</b>\nSKU stok rendah: <b>{low}</b>", parse_mode="HTML")


@router.message(Command("sale_void"))
async def sale_void(message: Message):
    try:
        fields = parse_pipe_fields(payload(message, "sale_void"), (1, 2))
        invoice, reason = fields[0], fields[1] if len(fields) == 2 else "Dibatalkan melalui Telegram"
    except ValueError as exc:
        await message.answer(f"⚠️ {html.escape(str(exc))}")
        return
    result = await run(message, lambda ident: pos.void_sale(ident, invoice, reason))
    if result:
        _, row, repeated = result
        await message.answer(("ℹ️ Invoice sudah void: " if repeated else "✅ Penjualan dibatalkan: ") + f"<code>{row['invoice_no']}</code>. Stok dikembalikan dan pemasukan di-void.", parse_mode="HTML")


@router.message(Command("opname_start"))
async def opname_start(message: Message):
    result = await run(message, lambda ident: pos.start_opname(ident, payload(message, "opname_start")))
    if result:
        _, row, existed = result
        await message.answer(("ℹ️ Melanjutkan" if existed else "✅ Memulai") + f" sesi opname <code>{row['id']}</code>.", parse_mode="HTML")


@router.message(Command("opname_count"))
async def opname_count(message: Message):
    try:
        sku, amount = parse_pipe_fields(payload(message, "opname_count"), 2)
        counted = parse_nonnegative_decimal(amount)
    except ValueError as exc:
        await message.answer(f"⚠️ {html.escape(str(exc))}")
        return
    result = await run(message, lambda ident: pos.count_opname(ident, sku, counted))
    if result:
        _, _, product, item = result
        await message.answer(f"✅ <code>{product['sku']}</code>: sistem {qty(item['system_qty'])}, fisik {qty(item['counted_qty'])}, selisih {qty(item['variance'])}.", parse_mode="HTML")


@router.message(Command("opname_post"))
async def opname_post(message: Message):
    result = await run(message, lambda ident: pos.post_opname(ident))
    if result:
        _, row, items = result
        await message.answer(f"✅ Opname <code>{row['id']}</code> diposting. {len(items)} produk diperbarui atomik.", parse_mode="HTML")


@router.message(Command("staff_list"))
async def staff_list(message: Message):
    result = await run(message, lambda ident: pos.list_staff(ident))
    if result:
        _, rows = result
        await message.answer("👥 <b>Staf usaha</b>\n" + "\n".join(
            f"• {html.escape(r['full_name'] or '-')} · <code>{r['telegram_user_id'] or '-'}</code> · {r['role']} · {'aktif' if r['is_active'] else 'nonaktif'}"
            for r in rows
        ), parse_mode="HTML")


@router.message(Command("staff_add"))
async def staff_add(message: Message):
    try:
        tg_id, name, role = parse_pipe_fields(payload(message, "staff_add"), 3)
        tg_id = int(tg_id)
    except (ValueError, TypeError) as exc:
        await message.answer(f"⚠️ Format: <code>/staff_add 123456789 | Nama | CASHIER</code>\n{html.escape(str(exc))}", parse_mode="HTML")
        return
    result = await run(message, lambda ident: pos.add_staff(ident, tg_id, name, role))
    if result:
        _, user, assigned = result
        await message.answer(f"✅ {html.escape(user['full_name'] or name)} ditambahkan sebagai <b>{assigned}</b> pada usaha ini.", parse_mode="HTML")


@router.message(Command("staff_role"))
async def staff_role(message: Message):
    try:
        tg_id, role = parse_pipe_fields(payload(message, "staff_role"), 2)
        tg_id = int(tg_id)
    except (ValueError, TypeError) as exc:
        await message.answer(f"⚠️ {html.escape(str(exc))}")
        return
    result = await run(message, lambda ident: pos.set_staff_role(ident, tg_id, role))
    if result:
        await message.answer(f"✅ Role staf diubah menjadi <b>{result[2]}</b>.", parse_mode="HTML")


@router.message(Command("staff_remove"))
async def staff_remove(message: Message):
    try:
        tg_id = int(payload(message, "staff_remove"))
    except ValueError:
        await message.answer("Format: <code>/staff_remove TELEGRAM_ID</code>", parse_mode="HTML")
        return
    result = await run(message, lambda ident: pos.remove_staff(ident, tg_id))
    if result:
        await message.answer("✅ Staf dinonaktifkan dari usaha ini.")
