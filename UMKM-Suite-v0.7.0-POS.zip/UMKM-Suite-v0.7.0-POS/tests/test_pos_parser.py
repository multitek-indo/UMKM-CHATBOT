import unittest
from decimal import Decimal

from app.permissions import can_manage_role, has_permission
from app.pos_parser import (
    normalize_sku, parse_nonnegative_money, parse_sale_items,
)


class PosParserTest(unittest.TestCase):
    def test_sku_normalization(self):
        self.assertEqual(normalize_sku(" kopi-01 "), "KOPI-01")

    def test_rejects_unsafe_sku(self):
        with self.assertRaises(ValueError):
            normalize_sku("kopi susu")

    def test_money_suffix(self):
        self.assertEqual(parse_nonnegative_money("1,5jt"), 1_500_000)

    def test_sale_items_combine_duplicates(self):
        self.assertEqual(
            parse_sale_items("kopi:2, KOPI:0.5"),
            [{"sku": "KOPI", "qty": Decimal("2.500")}],
        )

    def test_permissions(self):
        self.assertTrue(has_permission("CASHIER", "pos.sell"))
        self.assertFalse(has_permission("CASHIER", "finance.read"))
        self.assertTrue(can_manage_role("ADMIN", "CASHIER"))
        self.assertFalse(can_manage_role("ADMIN", "ADMIN"))
        self.assertFalse(can_manage_role("ADMIN", "OWNER"))


if __name__ == "__main__":
    unittest.main()
