#!/usr/bin/env bash
set -Eeuo pipefail

DB_CONTAINER="umkm-bot-db-1"
fail=0
check() { if eval "$2"; then echo "[OK] $1"; else echo "[FAIL] $1" >&2; fail=1; fi; }

check "Telegram release v0.7.0-pos" "test \"\$(cat /home/umkm-bot/current/VERSION)\" = v0.7.0-pos -o \"\$(cat /home/umkm-bot/current/VERSION)\" = 0.7.0-pos"
check "Database healthy" "docker exec ${DB_CONTAINER} pg_isready -U umkm_owner -d umkm_bot >/dev/null"
check "Telegram bot running" "test \"\$(docker inspect umkm-bot-bot-1 --format '{{.State.Running}}')\" = true"
check "Reminder worker running" "test \"\$(docker inspect umkm-bot-worker-1 --format '{{.State.Running}}')\" = true"
check "GOWA healthy/running" "test \"\$(docker inspect umkm-gowa-gowa-1 --format '{{.State.Running}}')\" = true"
check "WA bridge running" "test \"\$(docker inspect umkm-gowa-wa_bridge-1 --format '{{.State.Running}}')\" = true"
check "WA bridge health endpoint" "docker exec umkm-gowa-wa_bridge-1 python -c \"import urllib.request; urllib.request.urlopen('http://127.0.0.1:8080/health', timeout=5).read()\""

if [[ -f /home/umkm-suite-v0.7.0-pos.state ]]; then
  expected_gowa_id="$(sed -n 's/^GOWA_CONTAINER_ID=//p' /home/umkm-suite-v0.7.0-pos.state)"
  current_gowa_id="$(docker inspect umkm-gowa-gowa-1 --format '{{.Id}}')"
  check "Container GOWA tidak dibuat ulang" "test -n '${expected_gowa_id}' -a '${current_gowa_id}' = '${expected_gowa_id}'"
fi

table_count="$(docker exec "${DB_CONTAINER}" psql -X -U umkm_owner -d umkm_bot -Atc "select count(*) from information_schema.tables where table_schema='public' and table_name in ('products','sales','sale_items','sale_payments','stock_movements','stock_opname_sessions','stock_opname_items','tenant_counters')")"
check "8 tabel POS tersedia" "test '${table_count}' = 8"

forced_count="$(docker exec "${DB_CONTAINER}" psql -X -U umkm_owner -d umkm_bot -Atc "select count(*) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname in ('products','sales','sale_items','sale_payments','stock_movements','stock_opname_sessions','stock_opname_items','tenant_counters') and c.relrowsecurity and c.relforcerowsecurity")"
check "RLS FORCE aktif pada 8 tabel POS" "test '${forced_count}' = 8"

migration="$(docker exec "${DB_CONTAINER}" psql -X -U umkm_owner -d umkm_bot -Atc "select count(*) from schema_migrations where version='007'")"
check "Migration 007 tercatat" "test '${migration}' = 1"

if [[ "${fail}" -ne 0 ]]; then
  echo "FEATURE CHECK GAGAL" >&2
  exit 1
fi
echo "FEATURE CHECK LULUS"
