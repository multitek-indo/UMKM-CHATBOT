# Release Notes — UMKM Suite v0.7.0 POS

Tanggal paket: 2 September 2026

## Ditambahkan

- POS multi-channel Telegram dan WhatsApp.
- Intent AI `create_sale`, `stock_query`, dan `pos_summary` dengan konfirmasi sebelum sale ditulis.
- Katalog produk, stok minimum, stock movements, invoice, item sale, payment, dan stock opname.
- Penjualan dan void atomik terhadap stok dan pembukuan.
- Role `INVENTORY` dan permission matrix server-side.
- Manajemen staf tenant dari Telegram untuk OWNER/ADMIN.
- RLS `FORCE` pada delapan tabel POS.
- Installer dengan mode preflight, backup, feature check, dan rollback.

## Diperbaiki

- Role v0.6 yang sebelumnya hanya dibaca sekarang dipakai untuk membatasi aksi backend utama.
- ADMIN tidak dapat melihat atau mengelola tenant lain.
- User staf dapat ditempatkan pada tenant usaha yang sama tanpa dibuatkan bisnis terpisah.

## Kompatibilitas

- Berdasarkan source aktif UMKM Bot v0.6.0.
- Kompatibel dengan PostgreSQL 17 dan GOWA image v9.2.0 yang terinspeksi.
- Tidak mengubah kontrak webhook GOWA, token Telegram, kunci Groq, atau volume sesi WhatsApp.

## Verifikasi build

- Python compile check: lulus.
- Shell syntax check: lulus.
- Unit/package contract tests: 8 lulus.
- Verifikasi database live dan smoke test channel dijalankan oleh `feature_check.sh` setelah instalasi di VPS.
