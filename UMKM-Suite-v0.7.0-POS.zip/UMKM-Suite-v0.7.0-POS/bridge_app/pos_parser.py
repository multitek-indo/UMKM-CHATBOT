"""Strict parsers shared by POS chat handlers."""
from decimal import Decimal, InvalidOperation
import re


SKU_RE = re.compile(r"^[A-Z0-9][A-Z0-9._-]{0,39}$")


def normalize_sku(value: str) -> str:
    sku = (value or "").strip().upper()
    if not SKU_RE.fullmatch(sku):
        raise ValueError("SKU harus 1-40 karakter: huruf, angka, titik, garis atau underscore.")
    return sku


def parse_positive_decimal(value: str, *, max_value: str = "999999999.999") -> Decimal:
    raw = (value or "").strip().replace(" ", "").replace(",", ".")
    try:
        number = Decimal(raw)
    except InvalidOperation as exc:
        raise ValueError("Angka tidak valid.") from exc
    if number <= 0 or number > Decimal(max_value):
        raise ValueError("Angka harus lebih dari 0 dan masih dalam batas sistem.")
    return number.quantize(Decimal("0.001"))


def parse_nonnegative_decimal(value: str, *, max_value: str = "999999999.999") -> Decimal:
    raw = (value or "").strip().replace(" ", "").replace(",", ".")
    try:
        number = Decimal(raw)
    except InvalidOperation as exc:
        raise ValueError("Angka tidak valid.") from exc
    if number < 0 or number > Decimal(max_value):
        raise ValueError("Angka harus 0 atau lebih dan masih dalam batas sistem.")
    return number.quantize(Decimal("0.001"))


def parse_nonnegative_money(value: str) -> int:
    raw = (value or "").lower().strip().replace("rp", "").replace(" ", "")
    raw = raw.replace(",", ".")
    multiplier = 1
    for suffix, mult in (("ribu", 1_000), ("rb", 1_000), ("juta", 1_000_000), ("jt", 1_000_000)):
        if raw.endswith(suffix):
            multiplier, raw = mult, raw[:-len(suffix)]
            break
    try:
        result = int(Decimal(raw) * multiplier)
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("Nominal tidak valid.") from exc
    if result < 0 or result > 999_999_999_999:
        raise ValueError("Nominal di luar batas sistem.")
    return result


def parse_sale_items(value: str) -> list[dict]:
    combined: dict[str, Decimal] = {}
    for part in (value or "").split(","):
        if not part.strip():
            continue
        bits = part.split(":", 1)
        if len(bits) != 2:
            raise ValueError("Format item harus SKU:jumlah, dipisahkan koma.")
        sku = normalize_sku(bits[0])
        qty = parse_positive_decimal(bits[1], max_value="999999.999")
        combined[sku] = combined.get(sku, Decimal("0")) + qty
    if not combined:
        raise ValueError("Minimal satu item penjualan diperlukan.")
    if len(combined) > 50:
        raise ValueError("Maksimal 50 SKU per transaksi.")
    return [{"sku": sku, "qty": qty} for sku, qty in combined.items()]


def parse_pipe_fields(value: str, expected: int | tuple[int, ...]) -> list[str]:
    fields = [field.strip() for field in (value or "").split("|")]
    allowed = {expected} if isinstance(expected, int) else set(expected)
    if len(fields) not in allowed or any(not field for field in fields):
        want = "/".join(str(x) for x in sorted(allowed))
        raise ValueError(f"Jumlah kolom harus {want}, dipisahkan tanda |.")
    return fields
