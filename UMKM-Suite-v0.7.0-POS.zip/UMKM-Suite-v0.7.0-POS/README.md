# UMKM Suite v0.7.0 POS

Upgrade additive untuk sistem aktif UMKM Bot v0.6.0 dan UMKM GOWA stack v0.6.1. Paket ini memperluas aplikasi yang sudah ada; tidak memasang bot, database, GOWA, webhook, atau volume WhatsApp kedua.

## Hasil upgrade

- POS Telegram dan WhatsApp.
- AI mengenali penjualan, cek stok, dan laporan POS dari bahasa biasa; setiap aksi tulis hasil AI meminta konfirmasi.
- Produk, harga jual/modal, satuan, stok minimum, dan status aktif.
- Penjualan atomik: invoice, item, pembayaran, pengurangan stok, stock movement, dan pemasukan ke tabel `transactions` tersimpan dalam satu transaksi database.
- Pembatalan penjualan atomik: stok kembali; sale, payment, dan transaksi keuangan menjadi `void`.
- Stock opname draft → hitung fisik → posting.
- Laporan omzet, laba kotor, jumlah transaksi, dan stok rendah.
- Staf per tenant dengan role `OWNER`, `ADMIN`, `FINANCE`, `CASHIER`, `INVENTORY`, dan `VIEWER`.
- RLS `FORCE` untuk seluruh tabel bisnis POS.
- Backup, preflight, feature check, dan rollback aplikasi.

## Penerapan singkat di VPS

Unggah ZIP ke direktori kerja, misalnya `/home/msllab`, lalu:

```bash
cd /home/msllab
unzip UMKM-Suite-v0.7.0-POS.zip
cd UMKM-Suite-v0.7.0-POS
sudo ./scripts/install.sh --check
```

Pastikan hasil terakhir adalah `PREFLIGHT OK`. Baru terapkan:

```bash
sudo ./scripts/install.sh --apply
sudo ./scripts/status.sh
sudo ./scripts/feature_check.sh
```

Installer membuat dump PostgreSQL dan backup WA bridge sebelum perubahan. Hanya container `bot`, `worker`, dan `wa_bridge` yang dibangun ulang. Container `gowa`, volume `gowa_storage`, kredensial, pairing/session, webhook URL, database container, dan aplikasi lain tidak diubah.

## Uji pertama

Telegram:

```text
/pos
/product_add KOPI | Kopi Susu | 18000 | 9000 | 20 | cup | 5
/sale KOPI:2 | QRIS
Bahasa AI: jual 2 KOPI bayar QRIS
/products
/pos_report today
```

WhatsApp:

```text
MENU
9
POS PRODUK
POS JUAL KOPI:2 | QRIS
jual 2 KOPI bayar QRIS
POS LAPORAN HARI INI
```

Tambah staf dari akun OWNER/ADMIN melalui Telegram:

```text
/staff_add 123456789 | Nama Kasir | CASHIER
/staff_list
```

ADMIN hanya dapat mengelola role di bawahnya (`FINANCE`, `CASHIER`, `INVENTORY`, `VIEWER`). OWNER dapat mengelola `ADMIN` dan seluruh role di bawahnya. Tidak ada perintah lintas-tenant.

## Rollback

```bash
cd /home/msllab/UMKM-Suite-v0.7.0-POS
sudo ./scripts/rollback.sh --apply
```

Rollback mengembalikan source/container aplikasi. Migrasi database bersifat additive dan tidak dihapus agar data POS tidak musnah. Dump penuh tersedia pada path backup yang dicetak installer.

Dokumentasi lengkap: `docs/DEPLOYMENT.md`, `docs/INSPECTION_BASELINE.md`, dan `RELEASE_NOTES.md`.
